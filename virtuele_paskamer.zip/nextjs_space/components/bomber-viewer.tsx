'use client';

import { useEffect, useRef, useState } from 'react';
import { Loader2, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { SIZE_FACTORS } from '@/lib/garment-configs';

export function BomberViewer({ color, sizeLabel }: { color: string; sizeLabel: string }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const settingsRef = useRef({ color, sizeLabel });
  const resetRef = useRef<(() => void) | null>(null);
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [attempt, setAttempt] = useState(0);
  useEffect(() => { settingsRef.current = { color, sizeLabel }; }, [color, sizeLabel]);

  useEffect(() => {
    let stopped = false;
    let cleanup = () => {};
    setStatus('loading');
    const init = async () => {
      const THREE = await import('three');
      const [{ OrbitControls }, helpers, { EffectComposer }, { RenderPass }, { UnrealBloomPass }, { OutputPass }] = await Promise.all([
        import('three/examples/jsm/controls/OrbitControls.js'), import('@/lib/bomber-scene'),
        import('three/examples/jsm/postprocessing/EffectComposer.js'), import('three/examples/jsm/postprocessing/RenderPass.js'),
        import('three/examples/jsm/postprocessing/UnrealBloomPass.js'), import('three/examples/jsm/postprocessing/OutputPass.js'),
      ]);
      if (stopped || !containerRef.current) return;
      const host = containerRef.current;
      const renderer = new THREE.WebGLRenderer({ antialias: true });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
      renderer.domElement.setAttribute('aria-label', 'Draaibaar 3D-proefmodel van de bomberjas');
      renderer.domElement.style.touchAction = 'none';
      host.appendChild(renderer.domElement);
      const scene = new THREE.Scene();
      scene.background = new THREE.Color('#eee8e2');
      const lightCleanup = helpers.lightBomberScene(scene, renderer);
      const camera = new THREE.PerspectiveCamera(36, 1, 0.1, 30);
      camera.position.set(0, 0.07, 2.15);
      const controls = new OrbitControls(camera, renderer.domElement);
      controls.enableDamping = true;
      controls.enablePan = false;
      controls.minDistance = 1.25; controls.maxDistance = 4;
      controls.target.set(0, 0, 0);
      controls.saveState();
      resetRef.current = () => controls.reset();
      const floor = new THREE.Mesh(new THREE.PlaneGeometry(20, 20), new THREE.MeshStandardMaterial({ color: '#e8e1d9', roughness: 1 }));
      floor.rotation.x = -Math.PI / 2; floor.position.y = -0.52; floor.receiveShadow = true;
      scene.add(floor);
      const composer = new EffectComposer(renderer);
      const renderPass = new RenderPass(scene, camera);
      const bloom = new UnrealBloomPass(new THREE.Vector2(512, 512), 0.025, 0.3, 3);
      const output = new OutputPass();
      composer.addPass(renderPass); composer.addPass(bloom); composer.addPass(output);
      let model: import('three').Group | null = null;
      let frame = 0;
      const resize = () => {
        const width = host.clientWidth, height = host.clientHeight;
        if (!width || !height) return;
        camera.aspect = width / height; camera.updateProjectionMatrix();
        renderer.setSize(width, height); composer.setSize(width, height);
      };
      const observer = new ResizeObserver(resize);
      observer.observe(host); resize();
      cleanup = () => {
        cancelAnimationFrame(frame); observer.disconnect(); controls.dispose(); resetRef.current = null;
        if (model) helpers.disposeObject(model);
        helpers.disposeObject(floor); lightCleanup(); bloom.dispose(); output.dispose(); composer.dispose();
        renderer.dispose(); renderer.forceContextLoss(); renderer.domElement.remove();
      };
      model = await helpers.loadBomber();
      if (stopped) { helpers.disposeObject(model); return; }
      scene.add(model);
      let lastColor = '', lastSize = '';
      const render = () => {
        if (stopped || !model) return;
        const settings = settingsRef.current;
        if (settings.color !== lastColor) { helpers.tintBomber(model, settings.color); lastColor = settings.color; }
        if (settings.sizeLabel !== lastSize) {
          const factor = SIZE_FACTORS[settings.sizeLabel] ?? 1;
          model.scale.set(factor, 1, factor); lastSize = settings.sizeLabel;
        }
        controls.update(); composer.render(); frame = requestAnimationFrame(render);
      };
      renderer.domElement.addEventListener('webglcontextlost', () => {
        if (!stopped) { cancelAnimationFrame(frame); setStatus('error'); }
      }, { once: true });
      render(); setStatus('ready');
    };
    init().catch(error => { console.error('3D-jas laden:', error); cleanup(); if (!stopped) setStatus('error'); });
    return () => { stopped = true; cleanup(); };
  }, [attempt]);

  return <div>
    <div className="relative">
      <div ref={containerRef} className="aspect-[4/5] sm:aspect-[4/3] w-full overflow-hidden rounded-lg bg-muted" />
      {status === 'loading' && <div className="absolute inset-0 flex flex-col items-center justify-center bg-muted text-foreground rounded-lg gap-3" role="status"><Loader2 className="h-7 w-7 animate-spin" /><p>3D-jas met stoftextuur laden…</p></div>}
      {status === 'error' && <div className="absolute inset-0 flex flex-col items-center justify-center bg-muted text-foreground rounded-lg gap-3 p-5 text-center"><p>De 3D-jas kon niet worden weergegeven. Controleer je verbinding of probeer een andere browser.</p><Button onClick={() => setAttempt(value => value + 1)}>Opnieuw laden</Button></div>}
      {status === 'ready' && <span className="absolute left-3 top-3 rounded-full bg-white/95 text-zinc-800 px-3 py-1 text-xs font-medium shadow-sm">3D-proefmodel · Bomber</span>}
    </div>
    <div className="mt-3 flex items-center gap-3"><Button variant="outline" size="sm" disabled={status !== 'ready'} onClick={() => resetRef.current?.()}><RotateCcw className="mr-1 h-4 w-4" /> Vooraanzicht</Button><p className="text-xs text-muted-foreground">Sleep om rondom te kijken · Knijp om te zoomen</p></div>
    <p className="mt-3 text-xs leading-relaxed text-muted-foreground">Benadering op basis van de productfoto. Zij- en achterkant zijn gegenereerd. Kleur en maat tonen alleen een visuele indruk, geen bewezen pasvorm.</p>
  </div>;
}
