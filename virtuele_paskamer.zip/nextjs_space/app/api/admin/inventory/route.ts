export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { auth } from '@/auth';

async function checkAdmin() {
  const session = await auth();
  return session?.user?.role === 'admin';
}

export async function PUT(request: Request) {
  if (!(await checkAdmin())) return NextResponse.json({ error: 'Niet geautoriseerd' }, { status: 401 });
  try {
    const body = await request.json();
    const { items } = body ?? {};
    if (!Array.isArray(items)) {
      return NextResponse.json({ error: 'Items array verwacht' }, { status: 400 });
    }
    const results = await Promise.all(
      items.map((item: any) =>
        prisma.inventoryItem.upsert({
          where: {
            productId_colorVariantId_sizeVariantId: {
              productId: item?.productId ?? '',
              colorVariantId: item?.colorVariantId ?? '',
              sizeVariantId: item?.sizeVariantId ?? '',
            },
          },
          update: { stock: parseInt(item?.stock) || 0 },
          create: {
            productId: item?.productId ?? '',
            colorVariantId: item?.colorVariantId ?? '',
            sizeVariantId: item?.sizeVariantId ?? '',
            stock: parseInt(item?.stock) || 0,
          },
        })
      )
    );
    return NextResponse.json({ updated: results?.length ?? 0 });
  } catch (err: any) {
    console.error(err);
    return NextResponse.json({ error: 'Kon voorraad niet bijwerken' }, { status: 500 });
  }
}
