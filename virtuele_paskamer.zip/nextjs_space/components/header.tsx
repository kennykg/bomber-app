'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useSession, signOut } from 'next-auth/react';
import { ShoppingBag, Menu, X, User, LogOut, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { useCartStore } from '@/lib/cart-store';
import { ShoppingCart } from '@/components/shopping-cart';

export function Header() {
  const { data: session } = useSession();
  const [mounted, setMounted] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const items = useCartStore((s) => s?.items ?? []);

  useEffect(() => { setMounted(true); }, []);

  const cartCount = mounted ? (items ?? []).reduce((sum: number, i: any) => sum + (i?.quantity ?? 0), 0) : 0;
  const isAdmin = session?.user?.role === 'admin';

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/80 backdrop-blur-lg">
      <div className="mx-auto flex h-16 max-w-[1200px] items-center justify-between px-4">
        <Link href="/" className="font-display text-2xl font-bold tracking-tight text-primary">
          STIJLVOL
        </Link>

        <nav className="hidden items-center gap-1 md:flex">
          <Button variant="ghost" size="sm" asChild>
            <Link href="/">Collectie</Link>
          </Button>
          {isAdmin && (
            <Button variant="ghost" size="sm" asChild>
              <Link href="/admin"><Shield className="mr-1 h-4 w-4" />Beheer</Link>
            </Button>
          )}
        </nav>

        <div className="flex items-center gap-2">
          {mounted && session?.user ? (
            <Button variant="ghost" size="sm" onClick={() => signOut?.({ redirectTo: '/' })} className="hidden md:flex">
              <LogOut className="mr-1 h-4 w-4" />
              Uitloggen
            </Button>
          ) : mounted ? (
            <Button variant="ghost" size="sm" asChild className="hidden md:flex">
              <Link href="/login"><User className="mr-1 h-4 w-4" />Inloggen</Link>
            </Button>
          ) : null}

          <Sheet open={cartOpen} onOpenChange={setCartOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon" className="relative">
                <ShoppingBag className="h-5 w-5" />
                {cartCount > 0 && (
                  <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
                    {cartCount}
                  </span>
                )}
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-full sm:max-w-md">
              <ShoppingCart onClose={() => setCartOpen(false)} />
            </SheetContent>
          </Sheet>

          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-64">
              <nav className="mt-8 flex flex-col gap-2">
                <Button variant="ghost" asChild onClick={() => setMobileOpen(false)}>
                  <Link href="/">Collectie</Link>
                </Button>
                {isAdmin && (
                  <Button variant="ghost" asChild onClick={() => setMobileOpen(false)}>
                    <Link href="/admin"><Shield className="mr-1 h-4 w-4" />Beheer</Link>
                  </Button>
                )}
                {session?.user ? (
                  <Button variant="ghost" onClick={() => { signOut?.({ redirectTo: '/' }); setMobileOpen(false); }}>
                    <LogOut className="mr-1 h-4 w-4" />Uitloggen
                  </Button>
                ) : (
                  <Button variant="ghost" asChild onClick={() => setMobileOpen(false)}>
                    <Link href="/login"><User className="mr-1 h-4 w-4" />Inloggen</Link>
                  </Button>
                )}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
