import asyncio, json, hashlib
from playwright.async_api import async_playwright

URL='http://localhost:3000/paskamer/cmv6yhef8005lvl806hirsy5y'
POSE_FIXTURE='''window.Pose=class {
  constructor(){this.callback=()=>{};} setOptions(){} onResults(fn){this.callback=fn;}
  async initialize(){} async close(){} async send(){
    const f=window.fixture;
    const p=Array.from({length:33},()=>({x:0.5,y:0.5,z:0,visibility:1}));
    const w=p.map(v=>({...v})); const a=f.yaw;
    p[11]={x:0.5+0.23*Math.cos(a),y:0.25,z:-0.23*Math.sin(a),visibility:1};
    p[12]={x:0.5-0.23*Math.cos(a),y:0.25,z:0.23*Math.sin(a),visibility:1};
    p[23]={x:0.65,y:f.partial?1.2:0.72,z:0,visibility:f.partial?0.05:1};
    p[24]={x:0.35,y:f.partial?1.2:0.72,z:0,visibility:f.partial?0.05:1};
    w[11]={x:0.23*Math.cos(a),y:0,z:-0.23*Math.sin(a),visibility:1};
    w[12]={x:-0.23*Math.cos(a),y:0,z:0.23*Math.sin(a),visibility:1};
    this.callback({poseLandmarks:f.visible?p:null,poseWorldLandmarks:f.visible?w:null});
  }
};'''

async def main():
  async with async_playwright() as p:
    browser=await p.chromium.launch(headless=True,args=['--use-gl=angle','--use-angle=swiftshader','--enable-webgl','--ignore-gpu-blocklist','--enable-unsafe-swiftshader'])
    page=await browser.new_page(viewport={'width':1100,'height':1200})
    errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.on('console',lambda m:errors.append(m.text) if m.type=='error' else None)
    await page.add_init_script('''window.glStats={contexts:0,draws:0}; const getContext=HTMLCanvasElement.prototype.getContext; HTMLCanvasElement.prototype.getContext=function(...a){const c=getContext.apply(this,a);if(c&&String(a[0]).startsWith('webgl')&&!c.__counted){c.__counted=true;window.glStats.contexts++;const draw=c.drawElements.bind(c);c.drawElements=(...args)=>{window.glStats.draws++;return draw(...args);};}return c;};''')
    await page.goto(URL,wait_until='networkidle')
    await page.get_by_role('tab',name='360° weergave').click()
    await page.get_by_text('3D-proefmodel · Bomber',exact=True).wait_for(timeout=90000)
    canvas=page.locator('canvas[aria-label="Draaibaar 3D-proefmodel van de bomberjas"]')
    async def shot():return hashlib.sha256(await canvas.screenshot()).hexdigest()
    a=await shot(); box=await canvas.bounding_box()
    await page.mouse.move(box['x']+box['width']*.35,box['y']+box['height']*.5)
    await page.mouse.down(); await page.mouse.move(box['x']+box['width']*.7,box['y']+box['height']*.5,steps=15); await page.mouse.up()
    await page.wait_for_timeout(2000); b=await shot(); assert a!=b
    await page.get_by_role('button',name='Vooraanzicht',exact=True).click()
    await page.wait_for_timeout(2000); c=await shot(); assert c!=b
    await page.get_by_role('button',name='Olijf',exact=True).click()
    await page.wait_for_timeout(1500); d=await shot(); assert c!=d
    await page.get_by_role('button',name='XXL',exact=True).click()
    await page.wait_for_timeout(1500); e=await shot(); assert e!=d
    await page.get_by_role('button',name='Zwart',exact=True).click()
    await page.get_by_role('button',name='M',exact=True).click()
    print('STUDIO: real drag, reset, color, size changed rendered pixels',flush=True)
    await page.route('**/pose/pose.js',lambda route:route.fulfill(status=200,content_type='application/javascript',body=POSE_FIXTURE,headers={'Access-Control-Allow-Origin':'*'}))
    await page.get_by_role('tab',name='Live camera').click()
    await page.evaluate('''() => {
      window.fixture={yaw:0,partial:false,visible:true,calls:0,streams:[]};
      const c=document.createElement('canvas');c.width=640;c.height=480;
      const ctx=c.getContext('2d');ctx.fillStyle='#1c7090';ctx.fillRect(0,0,640,480);
      window.fixture.timer=setInterval(()=>ctx.fillRect(0,0,640,480),100);
      navigator.mediaDevices.getUserMedia=async()=>{window.fixture.calls++;const s=c.captureStream(10);window.fixture.streams.push(s);return s;};
    }''')
    await page.get_by_role('button',name='Camera starten',exact=True).click()
    try:
      await page.wait_for_function("document.querySelector('canvas[data-garment-mode]')?.dataset.garmentVisible==='true'",timeout=90000)
    except Exception:
      print('DIAGNOSTICS',await page.evaluate("() => ({text:document.body.innerText,video:document.querySelector('video')?.readyState})"),flush=True)
      print('ERRORS',json.dumps(errors),flush=True)
      raise
    async def image(): return await page.locator('canvas[data-garment-mode]').evaluate("c=>c.toDataURL()")
    initial=await image()
    pixel=await page.locator('canvas[data-garment-mode]').evaluate("c=>[...c.getContext('2d').getImageData(320,200,1,1).data]")
    assert pixel[:3]!=[28,112,144], 'Jacket not composited onto camera'
    await page.evaluate('window.fixture.yaw=0.8')
    await page.wait_for_timeout(1500); assert initial!=await image()
    await page.evaluate('window.fixture.partial=true')
    await page.wait_for_function("document.querySelector('[data-body-status]')?.dataset.bodyStatus==='partial'")
    assert await page.locator('canvas[data-garment-mode]').get_attribute('data-garment-visible')=='true'
    await page.evaluate('window.fixture.visible=false')
    await page.wait_for_function("document.querySelector('canvas[data-garment-mode]')?.dataset.garmentVisible==='false'")
    await page.evaluate('window.fixture.visible=true;window.fixture.yaw=0;window.fixture.partial=false')
    await page.wait_for_function("document.querySelector('canvas[data-garment-mode]')?.dataset.garmentVisible==='true'")
    await page.get_by_text('Plaatsing bijstellen',exact=True).click()
    before=await image()
    scale=page.get_by_role('slider',name='Visuele schaal',exact=True)
    await scale.focus(); await scale.press('ArrowRight'); await scale.press('ArrowRight'); await scale.press('ArrowRight')
    await page.wait_for_timeout(1200); assert before!=await image()
    await page.get_by_role('button',name='Plaatsing resetten',exact=True).click()
    async with page.expect_download() as download_info:
      await page.get_by_role('button',name='Screenshot',exact=True).click()
    download=await download_info.value
    assert download.suggested_filename.endswith('.png')
    await page.get_by_role('button',name='Camera stoppen',exact=True).click()
    assert await page.evaluate("window.fixture.streams.every(s=>s.getTracks().every(t=>t.readyState==='ended'))")
    await page.get_by_role('button',name='Camera starten',exact=True).click()
    await page.wait_for_function("document.querySelector('canvas[data-garment-mode]')?.dataset.garmentVisible==='true' && window.fixture.calls===2",timeout=90000)
    await page.get_by_role('tab',name='360° weergave').click()
    assert await page.evaluate("window.fixture.streams.every(s=>s.getTracks().every(t=>t.readyState==='ended'))")
    print('SIMULATED_POSE: live composition, yaw, partial hips, loss/recovery, scale/reset, screenshot download, restart and tab cleanup passed',flush=True)
    print('WEBGL',json.dumps(await page.evaluate('window.glStats')),flush=True)
    print('ERRORS',json.dumps(errors),flush=True)
    assert not errors
    await browser.close()

asyncio.run(main())
