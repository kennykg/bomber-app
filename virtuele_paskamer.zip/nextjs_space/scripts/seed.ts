import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

const PRODUCTS = [
  {
    name: 'Klassiek Wit T-shirt',
    description: 'Tijdloos wit katoenen T-shirt met ronde hals. Zacht, ademend en perfect voor elke gelegenheid.',
    price: 29.95,
    category: 'tops',
    garmentType: 'tshirt',
    imageUrl: 'https://cdn.abacus.ai/images/36168840-7c1d-4a9c-a9a5-a581b441efad.png',
    colors: [
      { name: 'Wit', hexCode: '#FFFFFF' },
      { name: 'Zwart', hexCode: '#1a1a1a' },
      { name: 'Grijs', hexCode: '#9CA3AF' },
    ],
    sizes: ['S', 'M', 'L', 'XL'],
  },
  {
    name: 'Oversized Hoodie',
    description: 'Ultiem comfort in deze oversized hoodie. Zachte fleece voering, ruim kangoeroe-zakje en verstelbaar koord.',
    price: 59.95,
    category: 'tops',
    garmentType: 'hoodie',
    imageUrl: 'https://cdn.abacus.ai/images/7a762418-91ef-4b70-89a6-424eb0c8b02e.png',
    colors: [
      { name: 'Salie', hexCode: '#8BA888' },
      { name: 'Zwart', hexCode: '#1a1a1a' },
      { name: 'Crème', hexCode: '#F5F0E8' },
    ],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
  },
  {
    name: 'Denim Jasje',
    description: 'Klassiek blauw denim trucker-jasje. Stevig katoen met borstzakken en knoopsluiting. Onmisbaar in elke garderobe.',
    price: 89.95,
    category: 'tops',
    garmentType: 'jacket',
    imageUrl: 'https://cdn.abacus.ai/images/e8f6566f-fdd1-495b-8572-306250456b85.png',
    colors: [
      { name: 'Blauw', hexCode: '#4A6FA5' },
      { name: 'Donkerblauw', hexCode: '#2C3E50' },
      { name: 'Lichtblauw', hexCode: '#87CEEB' },
    ],
    sizes: ['S', 'M', 'L', 'XL'],
  },
  {
    name: 'Linnen Overhemd',
    description: 'Luchtig linnen overhemd in een natuurlijke tint. Relaxte pasvorm, perfect voor warme dagen en casual chic.',
    price: 49.95,
    category: 'tops',
    garmentType: 'shirt',
    imageUrl: 'https://cdn.abacus.ai/images/240b31af-63e5-4bf5-b8d8-d86d0ddf0e66.png',
    colors: [
      { name: 'Naturel', hexCode: '#D4C5A9' },
      { name: 'Wit', hexCode: '#FAFAFA' },
      { name: 'Lichtblauw', hexCode: '#B0C4DE' },
    ],
    sizes: ['S', 'M', 'L', 'XL'],
  },
  {
    name: 'Katoenen Polo',
    description: 'Stijlvolle piqué polo in klassiek marineblauw. Geribbelde kraag en manchetten. Klasse in eenvoud.',
    price: 39.95,
    category: 'tops',
    garmentType: 'polo',
    imageUrl: 'https://cdn.abacus.ai/images/3b8e950e-47d3-4d3d-84cb-3dc673297994.png',
    colors: [
      { name: 'Marine', hexCode: '#1B2A4A' },
      { name: 'Wit', hexCode: '#FFFFFF' },
      { name: 'Bordeaux', hexCode: '#800020' },
    ],
    sizes: ['S', 'M', 'L', 'XL'],
  },
  {
    name: 'Wollen Trui',
    description: 'Warme kabelgebreide trui van zuivere wol in crème. Chunky breipatroon, ronde hals en geribbelde boorden.',
    price: 69.95,
    category: 'tops',
    garmentType: 'sweater',
    imageUrl: 'https://cdn.abacus.ai/images/e00fa4e7-1307-4e90-8f2c-3a6c88ba072d.png',
    colors: [
      { name: 'Crème', hexCode: '#FFFDD0' },
      { name: 'Camel', hexCode: '#C19A6B' },
      { name: 'Donkergrijs', hexCode: '#4A4A4A' },
    ],
    sizes: ['S', 'M', 'L', 'XL'],
  },
  {
    name: 'Bomber Jacket',
    description: 'Moderne zwarte bomber met nylon buitenkant. Geribbelde kraag, manchetten en zoom. Stoer en veelzijdig.',
    price: 99.95,
    category: 'tops',
    garmentType: 'jacket',
    imageUrl: 'https://cdn.abacus.ai/images/a4bb9579-ffa4-4cad-900e-7fba86ef924c.png',
    colors: [
      { name: 'Zwart', hexCode: '#111111' },
      { name: 'Olijf', hexCode: '#556B2F' },
      { name: 'Marine', hexCode: '#1B2A4A' },
    ],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
  },
  {
    name: 'Gestreept T-shirt',
    description: 'Klassiek Bretons gestreept T-shirt. Marineblauw en wit, lange mouwen, boothalslijn. Franse elegantie.',
    price: 34.95,
    category: 'tops',
    garmentType: 'tshirt',
    imageUrl: 'https://cdn.abacus.ai/images/0d36795f-3fd9-41a5-ae74-a8a8ce026e52.png',
    colors: [
      { name: 'Marine/Wit', hexCode: '#1B2A4A' },
      { name: 'Rood/Wit', hexCode: '#CC0000' },
      { name: 'Groen/Wit', hexCode: '#2E8B57' },
    ],
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
  },
];

async function main() {
  console.log('Seeding database...');

  // Hidden test admin account
  const adminHash = await bcrypt.hash('2#zjYYpMdh', 12);
  await prisma.user.upsert({
    where: { email: 'abacus-8cad517a@example.com' },
    update: { password: adminHash, role: 'admin' },
    create: { email: 'abacus-8cad517a@example.com', name: 'Admin', password: adminHash, role: 'admin' },
  });

  // Demo admin account for user
  const demoHash = await bcrypt.hash('Welkom123!', 12);
  await prisma.user.upsert({
    where: { email: 'beheerder@stijlvol.nl' },
    update: { password: demoHash, role: 'admin' },
    create: { email: 'beheerder@stijlvol.nl', name: 'Winkelbeheerder', password: demoHash, role: 'admin' },
  });

  for (const p of PRODUCTS) {
    const existing = await prisma.product.findFirst({ where: { name: p.name } });
    if (existing) {
      console.log(`Product "${p.name}" bestaat al, overslaan.`);
      continue;
    }

    const product = await prisma.product.create({
      data: {
        name: p.name,
        description: p.description,
        price: p.price,
        category: p.category,
        garmentType: p.garmentType,
        imageUrl: p.imageUrl,
        colors: {
          create: p.colors.map((c) => ({ name: c.name, hexCode: c.hexCode })),
        },
        sizes: {
          create: p.sizes.map((label, i) => ({ label, sortOrder: i })),
        },
      },
      include: { colors: true, sizes: true },
    });

    // Create inventory for each color+size combo
    for (const color of product.colors) {
      for (const size of product.sizes) {
        const stock = Math.floor(Math.random() * 20) + 1;
        await prisma.inventoryItem.upsert({
          where: {
            productId_colorVariantId_sizeVariantId: {
              productId: product.id,
              colorVariantId: color.id,
              sizeVariantId: size.id,
            },
          },
          update: { stock },
          create: {
            productId: product.id,
            colorVariantId: color.id,
            sizeVariantId: size.id,
            stock,
          },
        });
      }
    }

    console.log(`Product aangemaakt: ${p.name}`);
  }

  console.log('Seeding voltooid!');
}

main()
  .catch((e) => { console.error('Seed error:', e); process.exit(1); })
  .finally(() => prisma.$disconnect());
