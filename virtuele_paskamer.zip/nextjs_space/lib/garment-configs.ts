export interface GarmentConfig {
  neckType: 'round' | 'v' | 'collar' | 'polo' | 'hood';
  sleeveLength: number;
  looseness: number;
  hasZipper: boolean;
  hasButtons: boolean;
  hemDrop: number;
}

export const GARMENT_CONFIGS: Record<string, GarmentConfig> = {
  tshirt: { neckType: 'round', sleeveLength: 0.35, looseness: 1.0, hasZipper: false, hasButtons: false, hemDrop: 0.05 },
  hoodie: { neckType: 'hood', sleeveLength: 1.0, looseness: 1.3, hasZipper: false, hasButtons: false, hemDrop: 0.12 },
  jacket: { neckType: 'collar', sleeveLength: 1.0, looseness: 1.15, hasZipper: true, hasButtons: false, hemDrop: 0.08 },
  shirt: { neckType: 'collar', sleeveLength: 1.0, looseness: 1.0, hasZipper: false, hasButtons: true, hemDrop: 0.05 },
  polo: { neckType: 'polo', sleeveLength: 0.35, looseness: 1.0, hasZipper: false, hasButtons: true, hemDrop: 0.05 },
  sweater: { neckType: 'round', sleeveLength: 1.0, looseness: 1.1, hasZipper: false, hasButtons: false, hemDrop: 0.08 },
};

export const SIZE_FACTORS: Record<string, number> = {
  XS: 0.85, S: 0.92, M: 1.0, L: 1.08, XL: 1.16, XXL: 1.24,
};

export function getStockStatus(stock: number): { label: string; color: string } {
  if (stock <= 0) return { label: 'Uitverkocht', color: 'text-destructive' };
  if (stock <= 3) return { label: 'Bijna op', color: 'text-orange-500' };
  return { label: 'Op voorraad', color: 'text-green-600' };
}
