'use client';

import { useRef, useEffect, useState } from 'react';
import { RotateCcw, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface ThreeDViewerProps {
  garmentType: string;
  color: string;
  sizeLabel: string;
}

export function ThreeDViewer({ garmentType, color, sizeLabel }: ThreeDViewerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<any>(null);
  const sceneRef = useRef<any>(null);
  const clothingRef = useRef<any>(null);
  const controlsRef = useRef<any>(null);
  const [loading, setLoading] = useState(true);
  const [threeLoaded, setThreeLoaded] = useState(false);

  useEffect(() => {
    let mounted = true;
    const init = async () => {
      try {
        const THREE = await import('three');
        const { OrbitControls } = await import('three/examples/jsm/controls/OrbitControls.js');
        if (!mounted || !containerRef.current) return;

        const w = containerRef.current.clientWidth;
        const h = containerRef.current.clientHeight || 400;

        const scene = new THREE.Scene();
        scene.background = new THREE.Color(0xf5f0eb);
        sceneRef.current = scene;

        const camera = new THREE.PerspectiveCamera(45, w / h, 0.1, 100);
        camera.position.set(0, 1.2, 2.8);
        camera.lookAt(0, 1.0, 0);

        const renderer = new THREE.WebGLRenderer({ antialias: true });
        renderer.setSize(w, h);
        renderer.setPixelRatio(Math.min(window?.devicePixelRatio ?? 1, 2));
        renderer.shadowMap.enabled = true;
        containerRef.current.appendChild(renderer.domElement);
        rendererRef.current = renderer;

        const controls = new OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;
        controls.dampingFactor = 0.08;
        controls.target.set(0, 1.0, 0);
        controls.minDistance = 1.5;
        controls.maxDistance = 5;
        controlsRef.current = controls;

        // Lighting
        const ambient = new THREE.AmbientLight(0xffffff, 0.6);
        scene.add(ambient);
        const dir = new THREE.DirectionalLight(0xffffff, 0.8);
        dir.position.set(3, 5, 3);
        dir.castShadow = true;
        scene.add(dir);
        const fill = new THREE.DirectionalLight(0xffe0d0, 0.3);
        fill.position.set(-2, 3, -2);
        scene.add(fill);

        // Floor
        const floor = new THREE.Mesh(
          new THREE.CircleGeometry(2, 32),
          new THREE.MeshStandardMaterial({ color: 0xe8e0d8, roughness: 0.9 })
        );
        floor.rotation.x = -Math.PI / 2;
        floor.receiveShadow = true;
        scene.add(floor);

        // Mannequin
        const skinMat = new THREE.MeshStandardMaterial({ color: 0xd4a574, roughness: 0.7 });
        const createLimb = (geo: any, pos: [number, number, number], rot?: [number, number, number]) => {
          const m = new THREE.Mesh(geo, skinMat);
          m.position.set(...pos);
          if (rot) m.rotation.set(...rot);
          m.castShadow = true;
          scene.add(m);
          return m;
        };

        // Head
        createLimb(new THREE.SphereGeometry(0.1, 16, 16), [0, 1.65, 0]);
        // Neck
        createLimb(new THREE.CylinderGeometry(0.04, 0.05, 0.08, 8), [0, 1.52, 0]);
        // Torso
        createLimb(new THREE.BoxGeometry(0.35, 0.5, 0.18), [0, 1.2, 0]);
        // Upper arms
        createLimb(new THREE.CylinderGeometry(0.04, 0.045, 0.28, 8), [0.24, 1.3, 0], [0, 0, -0.2]);
        createLimb(new THREE.CylinderGeometry(0.04, 0.045, 0.28, 8), [-0.24, 1.3, 0], [0, 0, 0.2]);
        // Lower arms
        createLimb(new THREE.CylinderGeometry(0.035, 0.04, 0.28, 8), [0.32, 1.05, 0], [0, 0, -0.1]);
        createLimb(new THREE.CylinderGeometry(0.035, 0.04, 0.28, 8), [-0.32, 1.05, 0], [0, 0, 0.1]);
        // Upper legs
        createLimb(new THREE.CylinderGeometry(0.06, 0.055, 0.42, 8), [0.09, 0.72, 0]);
        createLimb(new THREE.CylinderGeometry(0.06, 0.055, 0.42, 8), [-0.09, 0.72, 0]);
        // Lower legs
        createLimb(new THREE.CylinderGeometry(0.05, 0.045, 0.42, 8), [0.09, 0.3, 0]);
        createLimb(new THREE.CylinderGeometry(0.05, 0.045, 0.42, 8), [-0.09, 0.3, 0]);
        // Feet
        createLimb(new THREE.BoxGeometry(0.08, 0.04, 0.14), [0.09, 0.07, 0.03]);
        createLimb(new THREE.BoxGeometry(0.08, 0.04, 0.14), [-0.09, 0.07, 0.03]);

        setThreeLoaded(true);
        setLoading(false);

        // Animation loop
        const animate = () => {
          if (!mounted) return;
          requestAnimationFrame(animate);
          controls?.update?.();
          renderer?.render?.(scene, camera);
        };
        animate();

        // Resize handler
        const onResize = () => {
          if (!containerRef.current || !mounted) return;
          const nw = containerRef.current.clientWidth;
          const nh = containerRef.current.clientHeight || 400;
          camera.aspect = nw / nh;
          camera.updateProjectionMatrix();
          renderer.setSize(nw, nh);
        };
        window.addEventListener('resize', onResize);
        return () => { window.removeEventListener('resize', onResize); };
      } catch (err: any) {
        console.error('3D viewer error:', err);
        if (mounted) setLoading(false);
      }
    };
    init();
    return () => {
      mounted = false;
      rendererRef.current?.dispose?.();
      if (containerRef.current && rendererRef.current?.domElement) {
        try { containerRef.current.removeChild(rendererRef.current.domElement); } catch {}
      }
    };
  }, []);

  // Update clothing mesh when color/garment/size changes
  useEffect(() => {
    if (!sceneRef.current || !threeLoaded) return;
    const updateClothing = async () => {
      try {
        const THREE = await import('three');
        // Remove old clothing
        if (clothingRef.current) {
          (clothingRef.current as any[])?.forEach?.((m: any) => sceneRef.current?.remove?.(m));
        }

        const hexColor = parseInt((color ?? '#333333').replace('#', ''), 16);
        const sf = ({ XS: 0.92, S: 0.96, M: 1.0, L: 1.04, XL: 1.08, XXL: 1.12 } as Record<string, number>)[sizeLabel] ?? 1.0;
        const mat = new THREE.MeshStandardMaterial({ color: hexColor, roughness: 0.85, metalness: 0.0 });
        const parts: any[] = [];

        // Torso clothing
        const torsoW = 0.38 * sf, torsoH = 0.54, torsoD = 0.22 * sf;
        const torso = new THREE.Mesh(new THREE.BoxGeometry(torsoW, torsoH, torsoD, 4, 4, 4), mat);
        torso.position.set(0, 1.2, 0);
        torso.castShadow = true;
        sceneRef.current.add(torso);
        parts.push(torso);

        // Sleeves
        const slLen = garmentType === 'tshirt' || garmentType === 'polo' ? 0.14 : 0.28;
        const rSleeve = new THREE.Mesh(new THREE.CylinderGeometry(0.055 * sf, 0.05 * sf, slLen, 8), mat);
        rSleeve.position.set(0.24, 1.38 - slLen / 2, 0);
        rSleeve.rotation.set(0, 0, -0.2);
        rSleeve.castShadow = true;
        sceneRef.current.add(rSleeve);
        parts.push(rSleeve);

        const lSleeve = new THREE.Mesh(new THREE.CylinderGeometry(0.055 * sf, 0.05 * sf, slLen, 8), mat);
        lSleeve.position.set(-0.24, 1.38 - slLen / 2, 0);
        lSleeve.rotation.set(0, 0, 0.2);
        lSleeve.castShadow = true;
        sceneRef.current.add(lSleeve);
        parts.push(lSleeve);

        // Hood for hoodie
        if (garmentType === 'hoodie') {
          const hood = new THREE.Mesh(new THREE.SphereGeometry(0.13, 12, 12, 0, Math.PI * 2, 0, Math.PI / 2),
            new THREE.MeshStandardMaterial({ color: hexColor, roughness: 0.85, side: THREE.DoubleSide }));
          hood.position.set(0, 1.55, -0.05);
          hood.castShadow = true;
          sceneRef.current.add(hood);
          parts.push(hood);
        }

        clothingRef.current = parts;
      } catch (err: any) {
        console.error('Clothing update error:', err);
      }
    };
    updateClothing();
  }, [color, garmentType, sizeLabel, threeLoaded]);

  const resetView = () => {
    if (controlsRef.current) {
      controlsRef.current.reset?.();
    }
  };

  return (
    <div className="relative w-full">
      <div ref={containerRef} className="aspect-[4/3] w-full overflow-hidden rounded-lg bg-muted" />
      {loading && (
        <div className="absolute inset-0 flex items-center justify-center bg-muted rounded-lg">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      )}
      <div className="mt-3 flex gap-2">
        <Button variant="outline" size="sm" onClick={resetView}>
          <RotateCcw className="mr-1 h-4 w-4" /> Weergave resetten
        </Button>
      </div>
      <p className="mt-2 text-xs text-muted-foreground">Sleep om te draaien · Scroll om in/uit te zoomen</p>
    </div>
  );
}
