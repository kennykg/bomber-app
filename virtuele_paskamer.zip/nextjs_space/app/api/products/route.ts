export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const products = await prisma.product.findMany({
      where: { active: true },
      include: {
        colors: true,
        sizes: { orderBy: { sortOrder: 'asc' } },
        inventory: true,
      },
      orderBy: { createdAt: 'desc' },
    });
    return NextResponse.json(products);
  } catch (err: any) {
    console.error('Products fetch error:', err);
    return NextResponse.json({ error: 'Kon producten niet ophalen' }, { status: 500 });
  }
}
