import asyncio, base64, io, json, hashlib
from pathlib import Path
from PIL import Image
from playwright.async_api import async_playwright

ROOT = Path('/home/ubuntu/virtuele_paskamer')
URL = 'http://localhost:3000/paskamer/cmv6yhef8005lvl806hirsy5y'
# The user screenshot is used only in local browser memory, never served or uploaded.
source_photo = Image.open('/home/ubuntu/Uploads/gallery_image_1791920232650.jpg')
# Coordinates refer to the 664x1440 displayed preview; scale to the original upload.
sx, sy = source_photo.width / 664, source_photo.height / 1440
photo = source_photo.crop((round(162*sx), round(405*sy), round(503*sx), round(859*sy)))
buffer = io.BytesIO(); photo.save(buffer, format='PNG')
photo_url = 'data:image/png;base64,' + base64.b64encode(buffer.getvalue()).decode()

INSTRUMENT = r'''(() => {
  window.testReport = {errors: [], drawCalls: 0, contexts: 0, cameraCalls: 0, streams: [], poseFrames: 0};
  const getContext = HTMLCanvasElement.prototype.getContext;
  HTMLCanvasElement.prototype.getContext = function(...args) {
    const context = getContext.apply(this, args);
    if (context && String(args[0]).startsWith('webgl') && !context.__counted) {
      context.__counted = true; window.testReport.contexts++;
      for (const name of ['drawElements','drawArrays']) {
        const fn = context[name].bind(context);
        context[name] = (...a) => { window.testReport.drawCalls++; return fn(...a); };
      }
    }
    return context;
  };
  let originalPose;
  Object.defineProperty(window, 'Pose', {configurable:true, get:()=>originalPose, set:value=>{
    originalPose = new Proxy(value, {construct(Target, args) {
      const pose = Reflect.construct(Target,args);
      const onResults = pose.onResults.bind(pose);
      pose.onResults = callback => onResults(result=>{
        window.testReport.poseFrames++;
        const p=result.poseLandmarks;
        window.testReport.lastLandmarks=p ? [11,12,23,24].map(i=>({index:i,x:p[i].x,y:p[i].y,visibility:p[i].visibility})) : null;
        callback(result);
      });
      return pose;
    }});
  }});
})();'''

async def main():
  async with async_playwright() as p:
    browser = await p.chromium.launch(headless=True, args=['--use-gl=angle','--use-angle=swiftshader','--enable-webgl','--ignore-gpu-blocklist','--enable-unsafe-swiftshader'])
    page = await browser.new_page(viewport={'width':1100,'height':1100}, device_scale_factor=1)
    errors=[]
    page.on('pageerror', lambda error: errors.append(str(error)))
    page.on('console', lambda msg: errors.append(msg.text) if msg.type=='error' else None)
    await page.add_init_script(INSTRUMENT)
    await page.goto(URL, wait_until='networkidle')
    await page.evaluate('''async source => {
      const image = new Image(); image.src=source; await image.decode();
      const canvas=document.createElement('canvas'); canvas.width=640; canvas.height=852;
      const ctx=canvas.getContext('2d');
      window.testFeed={canvas,ctx,image,visible:true};
      function draw() {ctx.fillStyle='#b3bdc3';ctx.fillRect(0,0,640,852);if(window.testFeed.visible){ctx.save();ctx.translate(640,0);ctx.scale(-1,1);ctx.drawImage(image,0,0,640,852);ctx.restore();}}
      draw(); window.testFeed.timer=setInterval(draw,120);
      navigator.mediaDevices.getUserMedia=async()=>{window.testReport.cameraCalls++;const s=canvas.captureStream(10);window.testReport.streams.push(s);return s;};
    }''', photo_url)
    await page.get_by_role('button',name='Camera starten',exact=True).click()
    try:
      await page.wait_for_function("window.testReport.poseFrames >= 3",timeout=90000)
    except Exception:
      print('DIAGNOSTIC',json.dumps(await page.evaluate("() => ({report: {...window.testReport, streams:undefined}, text:document.body.innerText,video:document.querySelector('video')?.readyState})")),flush=True)
      print('ERRORS',json.dumps(errors),flush=True)
      raise
    print('EARLY',json.dumps(await page.evaluate("() => ({report: {...window.testReport, streams:undefined}, text:document.body.innerText})")),flush=True)
    await page.wait_for_function("document.querySelector('canvas[data-garment-mode]')?.dataset.garmentVisible==='true'", timeout=30000)
    data=await page.evaluate('''() => ({status:document.querySelector('[data-body-status]')?.dataset.bodyStatus,landmarks:window.testReport.lastLandmarks,poseFrames:window.testReport.poseFrames,contexts:window.testReport.contexts,cameraCalls:window.testReport.cameraCalls,mode:document.querySelector('canvas[data-garment-mode]').dataset.garmentMode})''')
    print('REAL_PHOTO',json.dumps(data),flush=True)
    canvas=page.locator('canvas[data-garment-mode]')
    png=await canvas.evaluate("c=>c.toDataURL('image/png').split(',')[1]")
    (ROOT/'docs/live_bomber_photo_check.png').write_bytes(base64.b64decode(png))
    await page.evaluate('window.testFeed.visible=false')
    await page.wait_for_function("document.querySelector('[data-body-status]')?.dataset.bodyStatus==='searching' && document.querySelector('canvas[data-garment-mode]')?.dataset.garmentVisible==='false'",timeout=120000)
    print('LOST_BODY hidden and guidance shown',flush=True)
    await page.evaluate('window.testFeed.visible=true')
    await page.wait_for_function("document.querySelector('canvas[data-garment-mode]')?.dataset.garmentVisible==='true'",timeout=120000)
    await page.get_by_role('button',name='Camera stoppen',exact=True).click()
    stopped=await page.evaluate("window.testReport.streams.every(s=>s.getTracks().every(t=>t.readyState==='ended'))")
    assert stopped
    await page.get_by_role('button',name='Camera starten',exact=True).click()
    await page.wait_for_function("document.querySelector('canvas[data-garment-mode]')?.dataset.garmentVisible==='true' && window.testReport.cameraCalls===2", timeout=120000)
    print('RESTART two requests, old track ended, jacket visible again',flush=True)
    await page.get_by_role('button',name='Screenshot',exact=True).click()
    await page.get_by_role('tab',name='360° weergave').click()
    await page.get_by_text('3D-proefmodel · Bomber',exact=True).wait_for(timeout=120000)
    model=page.locator('canvas[aria-label="Draaibaar 3D-proefmodel van de bomberjas"]')
    await page.wait_for_function('window.testReport.drawCalls>20')
    async def pixels():
      return hashlib.sha256(await model.screenshot()).hexdigest()
    # Real pointer drag: compare pixels after the controls change the camera angle.
    a=await pixels(); box=await model.bounding_box()
    await page.mouse.move(box['x']+box['width']*.45,box['y']+box['height']*.5)
    await page.mouse.down(); await page.mouse.move(box['x']+box['width']*.75,box['y']+box['height']*.5,steps=15); await page.mouse.up()
    await page.wait_for_timeout(1800)
    b=await pixels(); assert a!=b,'Orbit drag did not change the rendered frame'
    await page.get_by_role('button',name='Vooraanzicht',exact=True).click()
    await page.wait_for_timeout(1500)
    await page.get_by_role('button',name='Olijf',exact=True).click()
    await page.wait_for_timeout(1500)
    c=await pixels(); assert c!=a,'Color did not update'
    await page.get_by_role('button',name='XXL',exact=True).click()
    await page.wait_for_timeout(1500)
    d=await pixels(); assert c!=d,'Size did not update'
    print('STUDIO orbit, reset, color and size controls changed rendered pixels',flush=True)
    print('ERRORS',json.dumps(errors),flush=True)
    assert not errors, 'Unexpected browser error'
    await browser.close()

asyncio.run(main())
