'use client';

import Link from 'next/link';
import Image from 'next/image';
import { motion } from 'framer-motion';
import { Shirt } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface ProductCardProps {
  id: string;
  name: string;
  price: number;
  imageUrl: string | null;
  colors: { id: string; name: string; hexCode: string }[];
}

export function ProductCard({ id, name, price, imageUrl, colors }: ProductCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="group overflow-hidden rounded-lg bg-card shadow-sm hover:shadow-md transition-shadow duration-300"
    >
      <Link href={`/paskamer/${id}`} className="block">
        <div className="relative aspect-[3/4] w-full overflow-hidden bg-muted">
          {imageUrl ? (
            <Image
              src={imageUrl}
              alt={name ?? 'Product'}
              fill
              className="object-cover transition-transform duration-500 group-hover:scale-105"
              sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
            />
          ) : (
            <div className="flex h-full items-center justify-center">
              <Shirt className="h-16 w-16 text-muted-foreground/30" />
            </div>
          )}
        </div>
      </Link>
      <div className="p-4">
        <h3 className="font-medium truncate">{name ?? 'Product'}</h3>
        <p className="text-lg font-semibold text-primary mt-1">€{(price ?? 0)?.toFixed?.(2) ?? '0.00'}</p>
        <div className="flex items-center gap-1.5 mt-2">
          {(colors ?? []).slice(0, 6).map((c: any, ci: number) => (
            <span
              key={c?.id ?? `c-${ci}`}
              className="h-4 w-4 rounded-full border border-border/50"
              style={{ backgroundColor: c?.hexCode ?? '#ccc' }}
              title={c?.name ?? ''}
            />
          ))}
        </div>
        <Button asChild size="sm" className="mt-3 w-full">
          <Link href={`/paskamer/${id}`}>
            <Shirt className="mr-1.5 h-4 w-4" />
            Passen
          </Link>
        </Button>
      </div>
    </motion.div>
  );
}
