'use client';

import { useState, useEffect } from 'react';
import { ShieldCheck, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function PrivacyBanner() {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const dismissed = typeof window !== 'undefined' ? localStorage?.getItem?.('privacy-dismissed') : null;
    if (!dismissed) setVisible(true);
  }, []);

  if (!visible) return null;

  const dismiss = () => {
    setVisible(false);
    try { localStorage?.setItem?.('privacy-dismissed', '1'); } catch {}
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 border-t bg-card p-4 shadow-lg">
      <div className="mx-auto flex max-w-[1200px] items-start gap-3">
        <ShieldCheck className="mt-0.5 h-5 w-5 flex-shrink-0 text-green-600" />
        <div className="flex-1">
          <p className="text-sm font-medium">Jouw privacy is gewaarborgd</p>
          <p className="text-xs text-muted-foreground mt-1">
            Alle camerabeelden worden uitsluitend lokaal in je browser verwerkt.
            Er worden geen beelden opgeslagen of naar een server verzonden.
            De virtuele paskamer werkt volledig op je eigen apparaat.
          </p>
        </div>
        <Button variant="ghost" size="icon" className="flex-shrink-0" onClick={dismiss}>
          <X className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
