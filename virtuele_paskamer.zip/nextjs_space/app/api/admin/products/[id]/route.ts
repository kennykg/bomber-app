export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { auth } from '@/auth';

async function checkAdmin() {
  const session = await auth();
  return session?.user?.role === 'admin';
}

export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!(await checkAdmin())) return NextResponse.json({ error: 'Niet geautoriseerd' }, { status: 401 });
  try {
    const { id } = await params;
    const body = await request.json();
    const { name, description, price, category, imageUrl, garmentType, active } = body ?? {};
    const product = await prisma.product.update({
      where: { id },
      data: {
        ...(name !== undefined && { name }),
        ...(description !== undefined && { description }),
        ...(price !== undefined && { price: parseFloat(price) || 0 }),
        ...(category !== undefined && { category }),
        ...(imageUrl !== undefined && { imageUrl }),
        ...(garmentType !== undefined && { garmentType }),
        ...(active !== undefined && { active }),
      },
      include: { colors: true, sizes: { orderBy: { sortOrder: 'asc' } }, inventory: true },
    });
    return NextResponse.json(product);
  } catch (err: any) {
    console.error(err);
    return NextResponse.json({ error: 'Kon product niet bijwerken' }, { status: 500 });
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!(await checkAdmin())) return NextResponse.json({ error: 'Niet geautoriseerd' }, { status: 401 });
  try {
    const { id } = await params;
    await prisma.product.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (err: any) {
    console.error(err);
    return NextResponse.json({ error: 'Kon product niet verwijderen' }, { status: 500 });
  }
}
