'use client';

import { useEffect, useState } from 'react';
import { Ruler, Info } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';

interface SizeAdvisorProps {
  shoulderWidth: number | null;
  torsoHeight: number | null;
  sizes: { id: string; label: string }[];
  onRecommend?: (sizeLabel: string) => void;
}

export function SizeAdvisor({ shoulderWidth, torsoHeight, sizes, onRecommend }: SizeAdvisorProps) {
  const [height, setHeight] = useState('');

  const getRecommendation = (): string | null => {
    if (!shoulderWidth || !torsoHeight) return null;
    const ratio = (shoulderWidth ?? 0) / (torsoHeight ?? 1);
    const heightCm = parseFloat(height) || 175;
    const scaleFactor = heightCm / 175;
    const adjustedRatio = ratio * scaleFactor;

    if (adjustedRatio < 0.7) return 'S';
    if (adjustedRatio < 0.85) return 'M';
    if (adjustedRatio < 1.0) return 'L';
    if (adjustedRatio < 1.15) return 'XL';
    return 'XXL';
  };

  const rec = getRecommendation();
  const available = (sizes ?? []).map((s: any) => s?.label ?? '');
  const recommended = rec && available.includes(rec) ? rec : null;

  useEffect(() => {
    if (recommended) onRecommend?.(recommended);
  }, [recommended, onRecommend]);

  return (
    <div className="rounded-lg border bg-card p-4">
      <div className="flex items-center gap-2 mb-3">
        <Ruler className="h-5 w-5 text-primary" />
        <h3 className="font-medium">Maatadvies</h3>
      </div>

      <div className="mb-3">
        <Label htmlFor="height" className="text-sm">Je lengte (cm) — optioneel</Label>
        <Input
          id="height"
          type="number"
          placeholder="175"
          value={height}
          onChange={(e: any) => setHeight(e?.target?.value ?? '')}
          className="mt-1"
        />
      </div>

      {recommended ? (
        <div className="rounded-md bg-primary/10 p-3">
          <div className="text-sm font-medium">
            Aanbevolen maat: <Badge variant="default" className="ml-1 text-sm">{recommended}</Badge>
          </div>
        </div>
      ) : (
        <p className="text-sm text-muted-foreground">
          {shoulderWidth ? 'Kan maat niet bepalen' : 'Ga voor de camera staan zodat we je lichaamsverhoudingen kunnen meten'}
        </p>
      )}

      <div className="mt-3 flex items-start gap-1.5">
        <Info className="h-3.5 w-3.5 mt-0.5 text-muted-foreground flex-shrink-0" />
        <p className="text-xs text-muted-foreground">
          Dit maatadvies is een indicatie op basis van geschatte lichaamsverhoudingen.
          Het is geen garantie voor een perfecte pasvorm.
        </p>
      </div>
    </div>
  );
}
