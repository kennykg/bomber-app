'use client';

import { useState, useEffect, useCallback } from 'react';
import { Package, Edit2, Save, Loader2, RefreshCw, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  imageUrl: string | null;
  garmentType: string;
  active: boolean;
  colors: { id: string; name: string; hexCode: string }[];
  sizes: { id: string; label: string }[];
  inventory: { id: string; colorVariantId: string; sizeVariantId: string; stock: number; colorVariant?: any; sizeVariant?: any }[];
}

export function AdminPanel() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<Partial<Product>>({});
  const [inventoryEdits, setInventoryEdits] = useState<Record<string, number>>({});
  const [saving, setSaving] = useState(false);

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/products');
      if (res.ok) {
        const data = await res.json();
        setProducts(data ?? []);
      }
    } catch (err: any) {
      console.error(err);
      toast.error('Kon producten niet laden');
    }
    setLoading(false);
  }, []);

  useEffect(() => { fetchProducts(); }, [fetchProducts]);

  const startEdit = (p: Product) => {
    setEditingId(p?.id ?? null);
    setEditForm({ name: p?.name, description: p?.description, price: p?.price, garmentType: p?.garmentType, active: p?.active });
    const invEdits: Record<string, number> = {};
    (p?.inventory ?? []).forEach((inv: any) => {
      invEdits[`${inv?.colorVariantId}-${inv?.sizeVariantId}`] = inv?.stock ?? 0;
    });
    // Fill missing combos
    (p?.colors ?? []).forEach((c: any) => {
      (p?.sizes ?? []).forEach((s: any) => {
        const key = `${c?.id}-${s?.id}`;
        if (invEdits[key] === undefined) invEdits[key] = 0;
      });
    });
    setInventoryEdits(invEdits);
  };

  const saveEdit = async (productId: string) => {
    setSaving(true);
    try {
      // Save product details
      await fetch(`/api/admin/products/${productId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editForm),
      });

      // Save inventory
      const items = Object.entries(inventoryEdits ?? {}).map(([key, stock]) => {
        const [colorVariantId, sizeVariantId] = (key ?? '').split('-');
        return { productId, colorVariantId: colorVariantId ?? '', sizeVariantId: sizeVariantId ?? '', stock };
      });
      await fetch('/api/admin/inventory', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items }),
      });

      toast.success('Product bijgewerkt!');
      setEditingId(null);
      fetchProducts();
    } catch (err: any) {
      console.error(err);
      toast.error('Opslaan mislukt');
    }
    setSaving(false);
  };

  const deleteProduct = async (id: string) => {
    if (!confirm('Weet je zeker dat je dit product wilt verwijderen?')) return;
    try {
      await fetch(`/api/admin/products/${id}`, { method: 'DELETE' });
      toast.success('Product verwijderd');
      fetchProducts();
    } catch {
      toast.error('Verwijderen mislukt');
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center py-12"><Loader2 className="h-8 w-8 animate-spin text-muted-foreground" /></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{(products ?? []).length} producten</p>
        <Button variant="outline" size="sm" onClick={fetchProducts}>
          <RefreshCw className="mr-1 h-4 w-4" /> Vernieuwen
        </Button>
      </div>

      {(products ?? []).map((product: Product, pIdx: number) => (
        <div key={product?.id ?? `prod-${pIdx}`} className="rounded-lg border bg-card p-4">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <Package className="h-5 w-5 text-primary" />
              {editingId === product?.id ? (
                <Input value={editForm?.name ?? ''} onChange={(e: any) => setEditForm({ ...editForm, name: e?.target?.value ?? '' })} className="font-medium" />
              ) : (
                <h3 className="font-medium">{product?.name ?? ''}</h3>
              )}
              <Badge variant={product?.active ? 'default' : 'secondary'}>{product?.active ? 'Actief' : 'Inactief'}</Badge>
            </div>
            <div className="flex gap-2">
              {editingId === product?.id ? (
                <Button size="sm" onClick={() => saveEdit(product?.id ?? '')} disabled={saving}>
                  {saving ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Save className="mr-1 h-4 w-4" />}
                  Opslaan
                </Button>
              ) : (
                <Button variant="outline" size="sm" onClick={() => startEdit(product)}>
                  <Edit2 className="mr-1 h-4 w-4" /> Bewerken
                </Button>
              )}
              <Button variant="ghost" size="icon" className="text-destructive" onClick={() => deleteProduct(product?.id ?? '')}>
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {editingId === product?.id && (
            <div className="mt-4 space-y-4">
              <div className="grid gap-4 sm:grid-cols-3">
                <div>
                  <Label>Prijs (€)</Label>
                  <Input type="number" step="0.01" value={editForm?.price ?? 0} onChange={(e: any) => setEditForm({ ...editForm, price: parseFloat(e?.target?.value) || 0 })} />
                </div>
                <div>
                  <Label>Kledingtype</Label>
                  <select value={editForm?.garmentType ?? 'tshirt'} onChange={(e: any) => setEditForm({ ...editForm, garmentType: e?.target?.value ?? 'tshirt' })}
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm">
                    <option value="tshirt">T-shirt</option>
                    <option value="hoodie">Hoodie</option>
                    <option value="jacket">Jasje</option>
                    <option value="shirt">Overhemd</option>
                    <option value="polo">Polo</option>
                    <option value="sweater">Trui</option>
                  </select>
                </div>
                <div className="flex items-end">
                  <label className="flex items-center gap-2 text-sm">
                    <input type="checkbox" checked={editForm?.active ?? true}
                      onChange={(e: any) => setEditForm({ ...editForm, active: e?.target?.checked ?? true })}
                      className="rounded border-input" />
                    Actief (zichtbaar)
                  </label>
                </div>
              </div>

              {/* Inventory grid */}
              <div>
                <h4 className="text-sm font-medium mb-2">Voorraad per kleur/maat</h4>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-2 pr-4">Kleur</th>
                        {(product?.sizes ?? []).map((s: any, si: number) => (
                          <th key={s?.id ?? `sh-${si}`} className="text-center py-2 px-2 min-w-[60px]">{s?.label ?? ''}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {(product?.colors ?? []).map((c: any, ci: number) => (
                        <tr key={c?.id ?? `cr-${ci}`} className="border-b">
                          <td className="py-2 pr-4 flex items-center gap-2">
                            <span className="h-4 w-4 rounded-full border" style={{ backgroundColor: c?.hexCode ?? '#ccc' }} />
                            {c?.name ?? ''}
                          </td>
                          {(product?.sizes ?? []).map((s: any) => {
                            const key = `${c?.id}-${s?.id}`;
                            return (
                              <td key={key} className="text-center py-2 px-1">
                                <Input
                                  type="number"
                                  min="0"
                                  value={inventoryEdits[key] ?? 0}
                                  onChange={(e: any) => setInventoryEdits({ ...(inventoryEdits ?? {}), [key]: parseInt(e?.target?.value) || 0 })}
                                  className="w-16 mx-auto text-center h-8 text-sm"
                                />
                              </td>
                            );
                          })}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {editingId !== product?.id && (
            <div className="mt-3 flex flex-wrap gap-2 text-xs text-muted-foreground">
              <span>€{(product?.price ?? 0)?.toFixed?.(2) ?? '0.00'}</span>
              <span>·</span>
              <span>{(product?.colors ?? []).length} kleuren</span>
              <span>·</span>
              <span>{(product?.sizes ?? []).length} maten</span>
              <span>·</span>
              <span>{product?.garmentType ?? ''}</span>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
