'use client';

import { useState } from 'react';
import { signIn } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { UserPlus, Mail, Lock, User, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Header } from '@/components/header';

export default function SignupPage() {
  const router = useRouter();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e?.preventDefault?.();
    setError('');
    if ((password?.length ?? 0) < 6) { setError('Wachtwoord moet minimaal 6 tekens zijn'); return; }
    setLoading(true);
    try {
      const res = await fetch('/api/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, name }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) { setError(data?.error ?? 'Registratie mislukt'); setLoading(false); return; }
      const result = await signIn('credentials', { email, password, redirect: false });
      if (result?.error) { setError('Account aangemaakt maar inloggen mislukt. Ga naar de inlogpagina.'); }
      else { router.replace('/'); }
    } catch {
      setError('Er ging iets mis. Probeer het opnieuw.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen">
      <Header />
      <div className="flex items-center justify-center px-4 py-16">
        <div className="w-full max-w-md rounded-xl border bg-card p-8 shadow-sm">
          <div className="text-center mb-6">
            <UserPlus className="mx-auto h-10 w-10 text-primary mb-3" />
            <h1 className="font-display text-2xl font-bold">Account aanmaken</h1>
            <p className="text-sm text-muted-foreground mt-1">Maak een beheerdersaccount aan</p>
          </div>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="name">Naam</Label>
              <div className="relative mt-1">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input id="name" value={name} onChange={(e: any) => setName(e?.target?.value ?? '')} placeholder="Je naam" className="pl-10" />
              </div>
            </div>
            <div>
              <Label htmlFor="email">E-mailadres</Label>
              <div className="relative mt-1">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input id="email" type="email" value={email} onChange={(e: any) => setEmail(e?.target?.value ?? '')} placeholder="je@email.nl" className="pl-10" required />
              </div>
            </div>
            <div>
              <Label htmlFor="password">Wachtwoord</Label>
              <div className="relative mt-1">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input id="password" type="password" value={password} onChange={(e: any) => setPassword(e?.target?.value ?? '')} placeholder="Min. 6 tekens" className="pl-10" required />
              </div>
            </div>
            {error && <p className="text-sm text-destructive">{error}</p>}
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Registreren
            </Button>
          </form>
          <p className="mt-4 text-center text-sm text-muted-foreground">
            Al een account? <Link href="/login" className="text-primary hover:underline">Inloggen</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
