'use client';

import { useCartStore, CartItem } from '@/lib/cart-store';
import { Button } from '@/components/ui/button';
import { Minus, Plus, Trash2, ShoppingBag } from 'lucide-react';
import Image from 'next/image';
import { useState, useEffect } from 'react';

export function ShoppingCart({ onClose }: { onClose?: () => void }) {
  const items = useCartStore((s) => s?.items ?? []);
  const removeItem = useCartStore((s) => s?.removeItem);
  const updateQuantity = useCartStore((s) => s?.updateQuantity);
  const clearCart = useCartStore((s) => s?.clearCart);
  const [mounted, setMounted] = useState(false);
  useEffect(() => { setMounted(true); }, []);

  if (!mounted) return <div className="p-6 text-center text-muted-foreground">Laden…</div>;

  const total = (items ?? []).reduce((sum: number, i: CartItem) => sum + (i?.price ?? 0) * (i?.quantity ?? 0), 0);

  if ((items ?? []).length === 0) {
    return (
      <div className="flex flex-col items-center justify-center gap-4 p-8 text-center">
        <ShoppingBag className="h-12 w-12 text-muted-foreground/50" />
        <p className="text-lg font-medium">Je winkelmandje is leeg</p>
        <p className="text-sm text-muted-foreground">Voeg items toe vanuit de collectie</p>
      </div>
    );
  }

  return (
    <div className="flex h-full flex-col">
      <h2 className="mb-4 font-display text-xl font-semibold">Winkelmandje</h2>
      <div className="flex-1 space-y-3 overflow-y-auto">
        {(items ?? []).map((item: CartItem, idx: number) => (
          <div key={`${item?.productId}-${item?.colorId}-${item?.sizeId}-${idx}`} className="flex gap-3 rounded-lg bg-muted/50 p-3">
            {item?.imageUrl ? (
              <div className="relative h-16 w-12 flex-shrink-0 overflow-hidden rounded bg-muted">
                <Image src={item.imageUrl} alt={item?.productName ?? ''} fill className="object-cover" sizes="48px" />
              </div>
            ) : (
              <div className="h-16 w-12 flex-shrink-0 rounded bg-muted" />
            )}
            <div className="flex-1 min-w-0">
              <p className="truncate text-sm font-medium">{item?.productName ?? 'Product'}</p>
              <p className="text-xs text-muted-foreground">
                <span className="inline-block h-2.5 w-2.5 rounded-full mr-1" style={{ backgroundColor: item?.colorHex ?? '#ccc' }} />
                {item?.colorName ?? ''} · {item?.sizeLabel ?? ''}
              </p>
              <div className="mt-1 flex items-center gap-2">
                <Button variant="outline" size="icon" className="h-6 w-6" onClick={() => updateQuantity?.(item?.productId ?? '', item?.colorId ?? '', item?.sizeId ?? '', (item?.quantity ?? 1) - 1)}>
                  <Minus className="h-3 w-3" />
                </Button>
                <span className="text-sm font-medium w-6 text-center">{item?.quantity ?? 0}</span>
                <Button variant="outline" size="icon" className="h-6 w-6" onClick={() => updateQuantity?.(item?.productId ?? '', item?.colorId ?? '', item?.sizeId ?? '', (item?.quantity ?? 0) + 1)}>
                  <Plus className="h-3 w-3" />
                </Button>
                <Button variant="ghost" size="icon" className="h-6 w-6 ml-auto text-destructive" onClick={() => removeItem?.(item?.productId ?? '', item?.colorId ?? '', item?.sizeId ?? '')}>
                  <Trash2 className="h-3 w-3" />
                </Button>
              </div>
            </div>
            <p className="text-sm font-semibold whitespace-nowrap">€{((item?.price ?? 0) * (item?.quantity ?? 0)).toFixed(2)}</p>
          </div>
        ))}
      </div>
      <div className="border-t pt-4 mt-4">
        <div className="flex justify-between text-lg font-semibold mb-4">
          <span>Totaal</span>
          <span>€{total?.toFixed?.(2) ?? '0.00'}</span>
        </div>
        <Button className="w-full mb-2" size="lg">Afrekenen (demo)</Button>
        <Button variant="outline" className="w-full" size="sm" onClick={() => clearCart?.()}>Mandje legen</Button>
      </div>
    </div>
  );
}
