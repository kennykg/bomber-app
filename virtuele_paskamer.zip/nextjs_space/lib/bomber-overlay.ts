import * as THREE from 'three';
import { disposeObject, lightBomberScene, loadBomber, tintBomber } from './bomber-scene';
import type { BodyPlacement } from './body-tracking';

export interface BomberOverlay {
  render: (body: BodyPlacement | null, width: number, height: number, color: string, size: number, adjustment: number, offset: number) => HTMLCanvasElement;
  dispose: () => void;
}

export async function createBomberOverlay(): Promise<BomberOverlay> {
  const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true, preserveDrawingBuffer: true });
  renderer.setClearColor(0x000000, 0);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  const scene = new THREE.Scene();
  const cleanupLight = lightBomberScene(scene, renderer);
  const camera = new THREE.OrthographicCamera(-0.5, 0.5, 0.5, -0.5, 0.1, 20);
  camera.position.z = 4;
  let model: THREE.Group;
  try { model = await loadBomber(); }
  catch (error) { cleanupLight(); renderer.dispose(); renderer.forceContextLoss(); throw error; }
  const anchor = new THREE.Group();
  model.position.y = -0.33;
  anchor.add(model);
  scene.add(anchor);
  const targetPosition = new THREE.Vector3();
  const targetScale = new THREE.Vector3();
  const rotation = new THREE.Quaternion();
  let oldWidth = 0, oldHeight = 0, oldColor = '', ready = false;
  let lastFrame = performance.now();
  return {
    render(body, width, height, color, size, adjustment, offset) {
      if (width !== oldWidth || height !== oldHeight) {
        renderer.setSize(width, height, false);
        camera.left = -width / height / 2; camera.right = width / height / 2;
        camera.updateProjectionMatrix();
        oldWidth = width; oldHeight = height;
      }
      if (color !== oldColor) { tintBomber(model, color); oldColor = color; }
      anchor.visible = !!body;
      const now = performance.now();
      const blend = 1 - Math.exp(-Math.min((now - lastFrame) / 1000, 0.1) * 14);
      lastFrame = now;
      if (body) {
        const widthScale = body.shoulder / height / 0.56;
        const lengthScale = body.torso / height / 0.72;
        targetPosition.set((body.x - width / 2) / height, (height / 2 - body.y - offset * body.torso) / height, 0);
        targetScale.set(widthScale * size * adjustment, lengthScale * adjustment, widthScale * size * adjustment);
        rotation.setFromEuler(new THREE.Euler(0, body.yaw, body.roll, 'ZYX'));
        if (!ready) { anchor.position.copy(targetPosition); anchor.scale.copy(targetScale); anchor.quaternion.copy(rotation); }
        else { anchor.position.lerp(targetPosition, blend); anchor.scale.lerp(targetScale, blend); anchor.quaternion.slerp(rotation, blend); }
        ready = true;
      } else ready = false;
      renderer.render(scene, camera);
      return renderer.domElement;
    },
    dispose() {
      disposeObject(model); cleanupLight(); renderer.dispose(); renderer.forceContextLoss();
    },
  };
}
