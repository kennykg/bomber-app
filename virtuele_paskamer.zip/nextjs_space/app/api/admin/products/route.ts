export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { auth } from '@/auth';

async function checkAdmin() {
  const session = await auth();
  return session?.user?.role === 'admin';
}

export async function GET() {
  if (!(await checkAdmin())) return NextResponse.json({ error: 'Niet geautoriseerd' }, { status: 401 });
  try {
    const products = await prisma.product.findMany({
      include: { colors: true, sizes: { orderBy: { sortOrder: 'asc' } }, inventory: { include: { colorVariant: true, sizeVariant: true } } },
      orderBy: { createdAt: 'desc' },
    });
    return NextResponse.json(products);
  } catch (err: any) {
    console.error(err);
    return NextResponse.json({ error: 'Fout bij ophalen' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  if (!(await checkAdmin())) return NextResponse.json({ error: 'Niet geautoriseerd' }, { status: 401 });
  try {
    const body = await request.json();
    const { name, description, price, category, imageUrl, garmentType, colors, sizes } = body ?? {};
    const product = await prisma.product.create({
      data: {
        name: name ?? 'Nieuw product',
        description: description ?? '',
        price: parseFloat(price) || 0,
        category: category ?? 'tops',
        imageUrl: imageUrl ?? null,
        garmentType: garmentType ?? 'tshirt',
        colors: {
          create: (colors ?? []).map((c: any) => ({ name: c?.name ?? '', hexCode: c?.hexCode ?? '#000000' })),
        },
        sizes: {
          create: (sizes ?? []).map((s: any, i: number) => ({ label: s?.label ?? 'M', sortOrder: i })),
        },
      },
      include: { colors: true, sizes: true },
    });
    return NextResponse.json(product, { status: 201 });
  } catch (err: any) {
    console.error(err);
    return NextResponse.json({ error: 'Kon product niet aanmaken' }, { status: 500 });
  }
}
