'use client';

import { useRef, useState, useEffect, useCallback } from 'react';
import { Camera, Download, RefreshCw, Loader2, VideoOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { GARMENT_CONFIGS, SIZE_FACTORS } from '@/lib/garment-configs';
import { BODY_GUIDANCE, getBodyPlacement, type BodyStatus, type Landmark } from '@/lib/body-tracking';
import type { BomberOverlay } from '@/lib/bomber-overlay';
import { toast } from 'sonner';

const scriptLoads = new Map<string, Promise<void>>();
function loadScript(src: string): Promise<void> {
  const existing = scriptLoads.get(src);
  if (existing) return existing;
  const promise = new Promise<void>((resolve, reject) => {
    const s = document.createElement('script');
    const timer = window.setTimeout(() => fail(), 20000);
    const fail = () => {
      window.clearTimeout(timer);
      s.remove();
      scriptLoads.delete(src);
      reject(new Error('Lichaamsdetectie kon niet worden geladen.'));
    };
    s.src = src; s.crossOrigin = 'anonymous';
    s.onload = () => { window.clearTimeout(timer); resolve(); };
    s.onerror = fail;
    document.head.appendChild(s);
  });
  scriptLoads.set(src, promise);
  return promise;
}

interface FittingRoomProps {
  garmentType: string;
  color: string;
  sizeLabel: string;
  hasBomberModel?: boolean;
  onBodyMeasurements?: (shoulder: number, torso: number) => void;
}

export function FittingRoom({ garmentType, color, sizeLabel, hasBomberModel = false, onBodyMeasurements }: FittingRoomProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [loading, setLoading] = useState(false);
  const [trackingWarning, setTrackingWarning] = useState<string | null>(null);
  const [pageUrl, setPageUrl] = useState('');
  const [embedded, setEmbedded] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const landmarksRef = useRef<any[] | null>(null);
  const animFrameRef = useRef<number>(0);
  const poseRef = useRef<any>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const runRef = useRef(0);
  const startingRef = useRef(false);
  const worldRef = useRef<Landmark[] | null>(null);
  const trackingTimeRef = useRef(0);
  const measurementTimeRef = useRef(0);
  const overlayRef = useRef<BomberOverlay | null>(null);
  const [modelStatus, setModelStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [modelAttempt, setModelAttempt] = useState(0);
  const [bodyStatus, setBodyStatus] = useState<BodyStatus>('searching');
  const [visualScale, setVisualScale] = useState(1);
  const [verticalOffset, setVerticalOffset] = useState(0);

  useEffect(() => {
    if (!hasBomberModel || !cameraActive) return;
    let cancelled = false;
    let instance: BomberOverlay | null = null;
    setModelStatus('loading');
    import('@/lib/bomber-overlay').then(module => module.createBomberOverlay()).then(overlay => {
      if (cancelled) { overlay.dispose(); return; }
      instance = overlay;
      overlayRef.current = overlay;
      setModelStatus('ready');
    }).catch(err => { console.error('Live 3D-jas laden:', err); if (!cancelled) setModelStatus('error'); });
    return () => {
      cancelled = true;
      if (overlayRef.current === instance) overlayRef.current = null;
      instance?.dispose();
    };
  }, [hasBomberModel, cameraActive, modelAttempt]);

  const config = GARMENT_CONFIGS[garmentType] ?? GARMENT_CONFIGS['tshirt'];
  const sizeFactor = SIZE_FACTORS[sizeLabel] ?? 1.0;

  const drawGarment = useCallback((ctx: CanvasRenderingContext2D, landmarks: any[], w: number, h: number) => {
    const get = (idx: number) => {
      const lm = landmarks?.[idx];
      if (!lm || (lm?.visibility ?? 0) < 0.4) return null;
      return { x: (1 - (lm?.x ?? 0)) * w, y: (lm?.y ?? 0) * h };
    };
    const ls = get(11), rs = get(12), le = get(13), re = get(14);
    const lw = get(15), rw = get(16), lh = get(23), rh = get(24), nose = get(0);
    if (!ls || !rs || !lh || !rh) return;

    const sw = Math.hypot((rs?.x ?? 0) - (ls?.x ?? 0), (rs?.y ?? 0) - (ls?.y ?? 0));
    const th = Math.hypot(
      ((ls?.x ?? 0) + (rs?.x ?? 0)) / 2 - ((lh?.x ?? 0) + (rh?.x ?? 0)) / 2,
      ((ls?.y ?? 0) + (rs?.y ?? 0)) / 2 - ((lh?.y ?? 0) + (rh?.y ?? 0)) / 2
    );
    if (onBodyMeasurements) onBodyMeasurements(sw, th);

    const pad = sw * 0.14 * (config?.looseness ?? 1) * sizeFactor;
    const neckW = sw * 0.28;
    const midSx = ((ls?.x ?? 0) + (rs?.x ?? 0)) / 2;
    const midSy = ((ls?.y ?? 0) + (rs?.y ?? 0)) / 2;
    const hemY = ((lh?.y ?? 0) + (rh?.y ?? 0)) / 2 + th * (config?.hemDrop ?? 0.05);

    ctx.save();
    ctx.globalAlpha = 0.72;

    // Main body
    ctx.beginPath();
    const neckY = midSy - sw * 0.12;

    if (config?.neckType === 'round' || config?.neckType === 'hood') {
      ctx.moveTo(midSx - neckW / 2, neckY);
      ctx.quadraticCurveTo(midSx, neckY + neckW * 0.35, midSx + neckW / 2, neckY);
    } else if (config?.neckType === 'v') {
      ctx.moveTo(midSx - neckW / 2, neckY);
      ctx.lineTo(midSx, neckY + neckW * 0.5);
      ctx.lineTo(midSx + neckW / 2, neckY);
    } else if (config?.neckType === 'collar' || config?.neckType === 'polo') {
      ctx.moveTo(midSx - neckW / 2, neckY - sw * 0.04);
      ctx.lineTo(midSx - neckW * 0.15, neckY);
      ctx.lineTo(midSx, neckY + neckW * 0.2);
      ctx.lineTo(midSx + neckW * 0.15, neckY);
      ctx.lineTo(midSx + neckW / 2, neckY - sw * 0.04);
    }

    // Right shoulder + sleeve
    ctx.lineTo((rs?.x ?? 0) + pad, (rs?.y ?? 0));
    if (re && (config?.sleeveLength ?? 0) > 0.3) {
      const t = config?.sleeveLength ?? 0.5;
      const endPt = (config?.sleeveLength ?? 0) >= 0.9 && rw ? rw : re;
      const sx = (rs?.x ?? 0) + ((endPt?.x ?? 0) - (rs?.x ?? 0)) * t;
      const sy = (rs?.y ?? 0) + ((endPt?.y ?? 0) - (rs?.y ?? 0)) * t;
      ctx.lineTo(sx + pad * 0.7, sy);
      ctx.lineTo(sx - pad * 0.3, sy + pad * 0.4);
    } else if (re) {
      const sx = (rs?.x ?? 0) + ((re?.x ?? 0) - (rs?.x ?? 0)) * 0.35;
      const sy = (rs?.y ?? 0) + ((re?.y ?? 0) - (rs?.y ?? 0)) * 0.35;
      ctx.lineTo(sx + pad * 0.5, sy);
      ctx.lineTo(sx - pad * 0.2, sy + pad * 0.3);
    }

    // Right side
    ctx.lineTo((rh?.x ?? 0) + pad * 0.6, hemY);
    // Hem
    ctx.lineTo((lh?.x ?? 0) - pad * 0.6, hemY);

    // Left sleeve
    if (le && (config?.sleeveLength ?? 0) > 0.3) {
      const t = config?.sleeveLength ?? 0.5;
      const endPt = (config?.sleeveLength ?? 0) >= 0.9 && lw ? lw : le;
      const sx = (ls?.x ?? 0) + ((endPt?.x ?? 0) - (ls?.x ?? 0)) * t;
      const sy = (ls?.y ?? 0) + ((endPt?.y ?? 0) - (ls?.y ?? 0)) * t;
      ctx.lineTo(sx - pad * 0.3, sy + pad * 0.4);
      ctx.lineTo(sx + pad * 0.7, sy);
    } else if (le) {
      const sx = (ls?.x ?? 0) + ((le?.x ?? 0) - (ls?.x ?? 0)) * 0.35;
      const sy = (ls?.y ?? 0) + ((le?.y ?? 0) - (ls?.y ?? 0)) * 0.35;
      ctx.lineTo(sx - pad * 0.2, sy + pad * 0.3);
      ctx.lineTo(sx + pad * 0.5, sy);
    }

    // Left shoulder
    ctx.lineTo((ls?.x ?? 0) - pad, (ls?.y ?? 0));
    ctx.closePath();

    // Gradient fill
    const grd = ctx.createLinearGradient(midSx - sw, midSy, midSx + sw, hemY);
    grd.addColorStop(0, color ?? '#333333');
    grd.addColorStop(0.5, adjustColor(color ?? '#333333', 15));
    grd.addColorStop(1, adjustColor(color ?? '#333333', -10));
    ctx.fillStyle = grd;
    ctx.fill();
    ctx.strokeStyle = adjustColor(color ?? '#333333', -30);
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // Details
    if (config?.hasButtons) {
      ctx.fillStyle = adjustColor(color ?? '#333333', -40);
      const btnCount = 5;
      for (let i = 0; i < btnCount; i++) {
        const by = neckY + neckW * 0.3 + (hemY - neckY - neckW * 0.3) * (i / btnCount);
        ctx.beginPath();
        ctx.arc(midSx, by, 3, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    if (config?.hasZipper) {
      ctx.strokeStyle = adjustColor(color ?? '#333333', -50);
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(midSx, neckY + neckW * 0.2);
      ctx.lineTo(midSx, hemY);
      ctx.stroke();
    }

    // Hood
    if (config?.neckType === 'hood' && nose) {
      ctx.globalAlpha = 0.5;
      ctx.beginPath();
      ctx.moveTo(midSx - neckW / 2, neckY);
      ctx.quadraticCurveTo((ls?.x ?? 0) - pad * 0.5, (nose?.y ?? 0) - sw * 0.3, midSx, (nose?.y ?? 0) - sw * 0.4);
      ctx.quadraticCurveTo((rs?.x ?? 0) + pad * 0.5, (nose?.y ?? 0) - sw * 0.3, midSx + neckW / 2, neckY);
      ctx.fillStyle = adjustColor(color ?? '#333333', -8);
      ctx.fill();
    }

    ctx.restore();
  }, [config, color, sizeFactor, onBodyMeasurements]);

  const onResults = useCallback((results: any) => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    if (!canvas || !video || video.readyState < 2) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    if (canvas.width !== video.videoWidth) canvas.width = video.videoWidth || 640;
    if (canvas.height !== video.videoHeight) canvas.height = video.videoHeight || 480;
    const w = canvas.width, h = canvas.height;

    ctx.save();
    ctx.translate(w, 0);
    ctx.scale(-1, 1);
    ctx.drawImage(video, 0, 0, w, h);
    ctx.restore();

    const lms = performance.now() - trackingTimeRef.current < 1200 ? results?.poseLandmarks : null;
    const body = getBodyPlacement(lms, w, h, worldRef.current);
    setBodyStatus(body ? (body.estimated ? 'partial' : 'tracked') : 'searching');
    if (hasBomberModel) {
      const overlay = overlayRef.current;
      if (overlay) {
        try {
          const layer = overlay.render(body, w, h, color, sizeFactor, visualScale, verticalOffset);
          ctx.drawImage(layer, 0, 0, w, h);
          canvas.dataset.garmentVisible = String(!!body);
          if (body && !body.estimated && performance.now() - measurementTimeRef.current > 500) {
            measurementTimeRef.current = performance.now();
            onBodyMeasurements?.(body.shoulder, body.torso);
          }
        } catch (err) {
          console.error('Live 3D-weergave:', err);
          overlayRef.current = null;
          canvas.dataset.garmentVisible = 'false';
          setModelStatus('error');
        }
      }
    } else if (lms && (lms?.length ?? 0) > 24) drawGarment(ctx, lms, w, h);
  }, [drawGarment, hasBomberModel, color, sizeFactor, visualScale, verticalOffset, onBodyMeasurements]);

  const resultsRef = useRef(onResults);
  useEffect(() => { resultsRef.current = onResults; }, [onResults]);

  const releaseCamera = useCallback(() => {
    runRef.current += 1;
    startingRef.current = false;
    cancelAnimationFrame(animFrameRef.current);
    streamRef.current?.getTracks().forEach(track => { track.onended = null; track.stop(); });
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
    const pose = poseRef.current;
    poseRef.current = null;
    if (pose) Promise.resolve(pose.close()).catch(err => console.error('Lichaamsdetectie afsluiten:', err));
    landmarksRef.current = null;
    worldRef.current = null;
    trackingTimeRef.current = 0;
  }, []);

  useEffect(() => {
    setPageUrl(window.location.href);
    setEmbedded(window.self !== window.top);
    return releaseCamera;
  }, [releaseCamera]);

  const startCamera = async () => {
    if (startingRef.current) return;
    releaseCamera();
    const run = runRef.current;
    startingRef.current = true;
    setLoading(true);
    setError(null);
    setTrackingWarning(null);
    setBodyStatus('searching');
    setCameraActive(false);
    try {
      if (!window.isSecureContext) throw new Error('Open deze pagina via een beveiligde https-verbinding om je camera te gebruiken.');
      const policy = (document as any).permissionsPolicy ?? (document as any).featurePolicy;
      if (policy && !policy.allowsFeature('camera')) throw new Error('Deze ingebouwde weergave blokkeert de camera. Open de paskamer rechtstreeks in Safari of Chrome.');
      if (!navigator.mediaDevices?.getUserMedia) throw new Error('Deze browser geeft geen cameratoegang. Open deze pagina rechtstreeks in Safari of Chrome, buiten de app.');
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: false,
        video: { facingMode: { ideal: 'user' }, width: { ideal: 640 }, height: { ideal: 480 } },
      });
      if (run !== runRef.current) { stream.getTracks().forEach(track => track.stop()); return; }
      streamRef.current = stream;
      const video = videoRef.current;
      if (!video) { releaseCamera(); return; }
      video.srcObject = stream;
      await video.play();
      if (run !== runRef.current) return;
      stream.getVideoTracks().forEach(track => {
        track.onended = () => {
          if (run !== runRef.current) return;
          releaseCamera();
          setCameraActive(false);
          setLoading(false);
          setTrackingWarning(null);
          setError('De cameraverbinding is gestopt. Controleer de toestemming en start de camera opnieuw.');
        };
      });
      setCameraActive(true);
      setLoading(false);
      startingRef.current = false;
      // Keep live video visible even if the separate tracking model fails.
      const render = () => {
        if (run !== runRef.current) return;
        resultsRef.current({ poseLandmarks: landmarksRef.current });
        animFrameRef.current = requestAnimationFrame(render);
      };
      render();
      setTrackingWarning('Lichaamsdetectie laden… Je camerabeeld is al beschikbaar.');
      try {
        await loadScript('https://cdn.jsdelivr.net/npm/@mediapipe/pose/pose.js');
        if (run !== runRef.current) return;
        const Pose = (window as any).Pose;
        if (!Pose) throw new Error('Lichaamsdetectie niet beschikbaar');
        const pose = new Pose({ locateFile: (file: string) => `https://cdn.jsdelivr.net/npm/@mediapipe/pose/${file}` });
        poseRef.current = pose;
        pose.setOptions({ modelComplexity: 1, smoothLandmarks: true, enableSegmentation: false, minDetectionConfidence: 0.5, minTrackingConfidence: 0.5 });
        pose.onResults((r: any) => {
          if (run === runRef.current) {
            landmarksRef.current = r?.poseLandmarks ?? null;
            worldRef.current = r?.poseWorldLandmarks ?? null;
            trackingTimeRef.current = performance.now();
          }
        });
        await pose.initialize();
        if (run !== runRef.current) return;
        setTrackingWarning(null);
        const trackFrame = async () => {
          if (run !== runRef.current) return;
          try {
            if (video.readyState >= 2) await pose.send({ image: video });
            if (run === runRef.current) requestAnimationFrame(() => { void trackFrame(); });
          } catch (err) {
            console.error('Lichaamsdetectie:', err);
            if (run === runRef.current) {
              landmarksRef.current = null;
              setTrackingWarning('De camera werkt, maar de kledingoverlay is niet beschikbaar. Stop en start de camera opnieuw, of gebruik de 360° weergave.');
            }
          }
        };
        void trackFrame();
      } catch (err) {
        console.error('Lichaamsdetectie laden:', err);
        if (run === runRef.current) setTrackingWarning('De camera werkt, maar lichaamsdetectie kon niet laden. Controleer je internetverbinding. Stop en start opnieuw, of gebruik de 360° weergave.');
      }
    } catch (err: any) {
      console.error('Camera starten:', err);
      if (run !== runRef.current) return;
      releaseCamera();
      const messages: Record<string, string> = {
        NotAllowedError: 'Cameratoegang is niet toegestaan. Geef deze website cameratoestemming in Safari of Chrome en controleer ook de cameratoestemming van die browser in je telefooninstellingen. Gebruik je de ingebouwde appbrowser? Open de link dan rechtstreeks in Safari of Chrome.',
        NotFoundError: 'Er is geen camera gevonden. Gebruik een toestel met camera of sluit een webcam aan.',
        NotReadableError: 'De camera kan niet worden geopend. Sluit andere apps die je camera gebruiken en controleer de cameratoestemming in je toestelinstellingen.',
        OverconstrainedError: 'Deze camera ondersteunt de gevraagde instellingen niet. Probeer een andere browser of camera.',
        SecurityError: 'Je browser blokkeert cameratoegang. Open deze pagina rechtstreeks in Safari of Chrome en controleer de toestemmingen.',
        AbortError: 'Het starten van de camera is onderbroken. Probeer opnieuw.',
      };
      setError(messages[err?.name] ?? err?.message ?? 'Kon de camera niet starten. Open de pagina rechtstreeks in Safari of Chrome.');
      setLoading(false);
      setCameraActive(false);
    }
  };

  const takeScreenshot = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.toBlob((blob: Blob | null) => {
      if (!blob) return;
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = `stijlvol-paskamer-${Date.now()}.png`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success('Screenshot opgeslagen!');
    }, 'image/png');
  };

  return (
    <div className="relative w-full">
      <video ref={videoRef} className="absolute h-px w-px opacity-0 pointer-events-none" playsInline muted autoPlay aria-hidden="true" />
      <div className="relative aspect-[4/3] w-full overflow-hidden rounded-lg bg-black">
        <canvas ref={canvasRef} className="h-full w-full object-contain" data-garment-mode={hasBomberModel ? '3d-bomber' : '2d'} />
        {cameraActive && hasBomberModel && modelStatus === 'ready' && <span className="absolute left-3 top-3 rounded-full bg-black/80 text-white px-3 py-1 text-xs font-medium">Live 3D · Proefmodel</span>}
        {!loading && !cameraActive && !error && (
          <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center text-white">
            <Camera className="h-10 w-10 mb-3" />
            <p className="text-sm mb-4">Start je camera en kies ‘Toestaan’ wanneer je browser daarom vraagt.</p>
            <Button onClick={startCamera}>Camera starten</Button>
          </div>
        )}
        {loading && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 text-white">
            <Loader2 className="h-8 w-8 animate-spin mb-3" />
            <p className="text-sm">Camera starten…</p>
            <p className="text-xs text-white/80 mt-1 text-center">Kies ‘Toestaan’ bij de cameravraag van je browser.</p>
          </div>
        )}
        {error && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/80 text-white p-4">
            <VideoOff className="h-10 w-10 mb-3 text-red-400" />
            <p className="text-sm text-center">{error}</p>
            <Button size="sm" className="mt-4 bg-white text-black hover:bg-white/90" onClick={startCamera}>
              <RefreshCw className="mr-1 h-4 w-4" /> Opnieuw proberen
            </Button>
          </div>
        )}
      </div>
      {trackingWarning && <p role="status" className="mt-3 text-sm text-foreground">{trackingWarning}</p>}
      {cameraActive && hasBomberModel && modelStatus === 'loading' && <p role="status" className="mt-3 flex items-center gap-2 text-sm"><Loader2 className="h-4 w-4 animate-spin" /> 3D-jas en stoftextuur laden…</p>}
      {cameraActive && hasBomberModel && modelStatus === 'error' && <div role="alert" className="mt-3 rounded-lg bg-muted text-foreground p-3 text-sm"><p>De 3D-jas kon niet laden. Je camera blijft beschikbaar. Controleer je internetverbinding; probeer zo nodig Chrome of Safari.</p><Button variant="outline" size="sm" className="mt-2" onClick={() => setModelAttempt(value => value + 1)}>3D-jas opnieuw laden</Button></div>}
      {cameraActive && !trackingWarning && (
        <div role="status" data-body-status={bodyStatus} className="mt-3 rounded-lg bg-muted text-foreground p-3 text-sm leading-relaxed">
          <p className="font-medium mb-1">{bodyStatus === 'tracked' ? 'Bovenlichaam in beeld' : bodyStatus === 'partial' ? 'Heupen nog buiten beeld' : 'Breng je bovenlichaam in beeld'}</p>
          <p>{!hasBomberModel && bodyStatus === 'partial' ? 'Voor dit kledingstuk moeten beide schouders én heupen zichtbaar zijn. Zet je telefoon verder weg.' : BODY_GUIDANCE[bodyStatus]}</p>
        </div>
      )}
      {hasBomberModel && <div className="mt-3 text-xs leading-relaxed text-muted-foreground">
        <p>3D-proefversie: de jas volgt je bovenlichaam als één geheel. Houd je armen langs je lichaam. Mouwen buigen nog niet afzonderlijk; handen en je echte kleding kunnen overlappen. Geen stofsimulatie of exacte maatmeting.</p>
      </div>}
      {cameraActive && hasBomberModel && modelStatus === 'ready' && <details className="mt-3 rounded-lg bg-muted text-foreground p-3 text-sm">
        <summary className="cursor-pointer font-medium">Plaatsing bijstellen</summary>
        <p className="mt-2 text-xs text-muted-foreground">Alleen voor de visuele uitlijning; dit verandert je gekozen kledingmaat niet.</p>
        <label className="block mt-3">Visuele schaal: {Math.round(visualScale * 100)}%<input aria-label="Visuele schaal" type="range" min="0.8" max="1.2" step="0.01" value={visualScale} onChange={event => setVisualScale(Number(event.target.value))} className="block mt-2 w-full accent-primary" /></label>
        <label className="block mt-3">Hoogte bijstellen<input aria-label="Hoogte bijstellen" type="range" min="-0.2" max="0.2" step="0.01" value={verticalOffset} onChange={event => setVerticalOffset(Number(event.target.value))} className="block mt-2 w-full accent-primary" /></label>
        <Button className="mt-3" size="sm" variant="outline" onClick={() => { setVisualScale(1); setVerticalOffset(0); }}>Plaatsing resetten</Button>
      </details>}
      {(embedded || error || !cameraActive) && pageUrl && (
        <div className="mt-3 text-sm text-muted-foreground">
          <p>Werkt de camera niet in de app of preview? Open deze pagina rechtstreeks in Safari of Chrome. Gebruik zo nodig ‘Open in browser’ in het menu van je app.</p>
          <a href={pageUrl} target="_blank" rel="noopener noreferrer" className="mt-2 inline-block text-primary underline">Paskamer apart openen</a>
        </div>
      )}
      {cameraActive && (
        <div className="mt-3 flex flex-wrap gap-2">
          <Button variant="outline" size="sm" onClick={() => { releaseCamera(); setCameraActive(false); setLoading(false); setTrackingWarning(null); }}>
            <VideoOff className="mr-1 h-4 w-4" /> Camera stoppen
          </Button>
          <Button variant="outline" size="sm" onClick={takeScreenshot}>
            <Download className="mr-1 h-4 w-4" /> Screenshot
          </Button>
        </div>
      )}
    </div>
  );
}

function adjustColor(hex: string, amount: number): string {
  try {
    const h = (hex ?? '#333333').replace('#', '');
    const r = Math.max(0, Math.min(255, parseInt(h.substring(0, 2), 16) + amount));
    const g = Math.max(0, Math.min(255, parseInt(h.substring(2, 4), 16) + amount));
    const b = Math.max(0, Math.min(255, parseInt(h.substring(4, 6), 16) + amount));
    return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
  } catch { return hex ?? '#333333'; }
}
