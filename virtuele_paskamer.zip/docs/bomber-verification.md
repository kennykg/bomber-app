# 3D-bomberproef — 13 oktober 2026

## Afbakening
Alleen product cmv6yhef8005lvl806hirsy5y heeft dit model. Andere kleding houdt de bestaande 2D-camera-overlay en geometrische viewer. Originele productfoto en voorraad zijn niet gewijzigd.

## Model
public/models/bomber-v1.glb is gegenereerd uit een aparte referentie van de bestaande productfoto. PBR-kleur-, normal- en metallic/roughness-texturen; 29.414 driehoeken. Voorzijde +X in het bronbestand, in de app naar +Z gedraaid. Schouderanker op genormaliseerde y=0, modelpositie -0,33. Beweging is een transformatie van de HELE jas, geen rig of stofsimulatie. Zij- en achterkant zijn schattingen. Niet geschikt als maatgarantie.

## Controles
- Bouw en types gecontroleerd via platformtests; definitieve testuitvoer/checkpoint blijft leidend.
- Draaibare viewer op volledige kwaliteit vastgelegd in capture_bomber_final.png: zwart textiel, plooien, rits, ribboorden en schaduw zichtbaar. Studioverlichting wijkt af van productfotografie. Softwarematige renderer; snelheid niet representatief voor een telefoon.
- Browser met gecontroleerde lichaamslandmarks en synthetische camerastream: 3D-compositie, rotatie, heupen buiten beeld, verlies/herstel detectie, visuele schaal/reset, screenshotdownload, herstart en stream opruimen bij tabwissel slaagden. Draaien/reset, kleuren en maten veranderen de gerenderde pixels.
- Dezelfde test signaleerde bestaande fouten in SizeAdvisor (callback tijdens render, div binnen p). Deze zijn daarna gericht aangepast. De volledige browsertest is niet opnieuw uitgevoerd; claim daarom geen foutloos end-to-end testresultaat.
- Pogingen met de gebruikersfoto zijn GEEN bewijs over echte detectie: de lokale testuitsnede was aanvankelijk niet naar de resolutie van de originele upload geschaald. Testfixture gecorrigeerd, niet opnieuw uitgevoerd wegens limiet op herhaalde browserpogingen. Geen gebruikersfoto als appasset opgeslagen.
- Nog niet bevestigd: echte live lichaamstracking en prestaties op de telefoon van de gebruiker. Laat beide schouders en bij voorkeur de heupen in beeld komen; frontaal licht. Test met de gebruiker voordat deze proef als productieklare paskamer wordt gepresenteerd.
