import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { BOMBER_MODEL_URL } from './bomber-config';

export function disposeObject(root: THREE.Object3D) {
  const textures = new Set<THREE.Texture>();
  const materials = new Set<THREE.Material>();
  root.traverse(object => {
    if (!(object instanceof THREE.Mesh)) return;
    object.geometry.dispose();
    for (const material of Array.isArray(object.material) ? object.material : [object.material]) {
      materials.add(material);
      Object.values(material).forEach(value => { if (value instanceof THREE.Texture) textures.add(value); });
    }
  });
  textures.forEach(texture => texture.dispose());
  materials.forEach(material => material.dispose());
}

export async function loadBomber() {
  const gltf = await new GLTFLoader().loadAsync(BOMBER_MODEL_URL);
  const root = new THREE.Group();
  const oriented = new THREE.Group();
  // Generator: Y up, front along +X. Convert to front +Z for the camera.
  oriented.rotation.y = -Math.PI / 2;
  oriented.add(gltf.scene);
  root.add(oriented);
  root.updateMatrixWorld(true);
  const box = new THREE.Box3().setFromObject(root);
  const size = box.getSize(new THREE.Vector3());
  const center = box.getCenter(new THREE.Vector3());
  oriented.position.sub(center);
  const normalization = 1 / size.y;
  oriented.scale.setScalar(normalization);
  oriented.position.multiplyScalar(normalization);
  root.traverse(object => {
    if (!(object instanceof THREE.Mesh)) return;
    object.castShadow = true;
    object.receiveShadow = true;
    for (const material of Array.isArray(object.material) ? object.material : [object.material]) {
      if (material instanceof THREE.MeshStandardMaterial) {
        material.envMapIntensity = 0.12;
        // Nylon is dielectric; the generator's metallic map must not behave like chrome.
        material.metalness = 0.15;
        material.side = THREE.DoubleSide;
        // The generated albedo is lifted for studio viewing; restore the black nylon base.
        material.color.multiplyScalar(0.22);
        material.userData.originalColor = material.color.clone();
        if (material.map) material.map.anisotropy = 4;
      }
    }
  });
  return root;
}

export function tintBomber(root: THREE.Object3D, hex: string) {
  const tint = new THREE.Color(hex);
  const max = Math.max(tint.r, tint.g, tint.b);
  // Keep the original black fabric map intact. Other swatches are visual approximations.
  if (max < 0.015) tint.setRGB(1, 1, 1);
  else tint.multiplyScalar(1 / Math.max(max, 0.001));
  root.traverse(object => {
    if (!(object instanceof THREE.Mesh)) return;
    for (const material of Array.isArray(object.material) ? object.material : [object.material]) {
      if (material instanceof THREE.MeshStandardMaterial) material.color.copy(material.userData.originalColor).multiply(tint);
    }
  });
}

export function lightBomberScene(scene: THREE.Scene, renderer: THREE.WebGLRenderer, live = false) {
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 0.95;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  const pmrem = new THREE.PMREMGenerator(renderer);
  const room = new RoomEnvironment();
  const environment = pmrem.fromScene(room, 0.04);
  room.dispose(); pmrem.dispose();
  scene.environment = environment.texture;
  scene.environmentIntensity = 0.8;
  const hemi = new THREE.HemisphereLight(0xeaf2ff, 0x776459, 0.7);
  const key = new THREE.DirectionalLight(0xfff2df, 2.5);
  key.position.set(-2, 3, 4);
  key.castShadow = !live;
  key.shadow.mapSize.set(1024, 1024);
  key.shadow.camera.left = -1.5; key.shadow.camera.right = 1.5;
  key.shadow.camera.top = 1.5; key.shadow.camera.bottom = -1.5;
  key.shadow.bias = -0.0002;
  const rim = new THREE.DirectionalLight(0xe0ebff, 2);
  rim.position.set(2, 1, -2);
  scene.add(hemi, key, rim);
  return () => { scene.environment = null; environment.dispose(); key.shadow.dispose(); };
}
