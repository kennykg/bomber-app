import { prisma } from '@/lib/prisma';
import { notFound } from 'next/navigation';
import { Header } from '@/components/header';
import { PaskamerClient } from './paskamer-client';

export const dynamic = 'force-dynamic';

export default async function PaskamerPage({ params }: { params: Promise<{ productId: string }> }) {
  const { productId } = await params;
  const product = await prisma.product.findUnique({
    where: { id: productId },
    include: {
      colors: true,
      sizes: { orderBy: { sortOrder: 'asc' } },
      inventory: { include: { colorVariant: true, sizeVariant: true } },
    },
  });

  if (!product) notFound();

  const serialized = {
    id: product?.id ?? '',
    name: product?.name ?? '',
    description: product?.description ?? '',
    price: product?.price ?? 0,
    imageUrl: product?.imageUrl ?? null,
    garmentType: product?.garmentType ?? 'tshirt',
    colors: (product?.colors ?? []).map((c: any) => ({ id: c?.id ?? '', name: c?.name ?? '', hexCode: c?.hexCode ?? '#ccc' })),
    sizes: (product?.sizes ?? []).map((s: any) => ({ id: s?.id ?? '', label: s?.label ?? 'M' })),
    inventory: (product?.inventory ?? []).map((inv: any) => ({
      colorVariantId: inv?.colorVariantId ?? '',
      sizeVariantId: inv?.sizeVariantId ?? '',
      stock: inv?.stock ?? 0,
      colorName: inv?.colorVariant?.name ?? '',
      sizeName: inv?.sizeVariant?.label ?? '',
    })),
  };

  return (
    <div className="min-h-screen">
      <Header />
      <PaskamerClient product={serialized} />
    </div>
  );
}
