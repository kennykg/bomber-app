import { auth } from '@/auth';
import { redirect } from 'next/navigation';
import { Header } from '@/components/header';
import { AdminPanel } from '@/components/admin-panel';

export const dynamic = 'force-dynamic';

export default async function AdminPage() {
  const session = await auth();
  if (!session?.user) redirect('/login');
  if (session?.user?.role !== 'admin') {
    return (
      <div className="min-h-screen">
        <Header />
        <div className="mx-auto max-w-[1200px] px-4 py-16 text-center">
          <h1 className="font-display text-2xl font-bold">Geen toegang</h1>
          <p className="mt-2 text-muted-foreground">Je hebt geen beheerdersrechten. Neem contact op met de winkeleigenaar.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Header />
      <div className="mx-auto max-w-[1200px] px-4 py-8">
        <h1 className="font-display text-3xl font-bold tracking-tight mb-2">Productbeheer</h1>
        <p className="text-muted-foreground mb-8">Beheer producten, kleuren, maten en voorraad</p>
        <AdminPanel />
      </div>
    </div>
  );
}
