// This proof model belongs only to the original Bomber Jacket, not every jacket.
export const BOMBER_PRODUCT_ID = 'cmv6yhef8005lvl806hirsy5y';
export const BOMBER_MODEL_URL = '/models/bomber-v1.glb';
