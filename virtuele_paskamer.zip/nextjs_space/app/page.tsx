import { prisma } from '@/lib/prisma';
import { Header } from '@/components/header';
import { ProductCard } from '@/components/product-card';
import { PrivacyBanner } from '@/components/privacy-banner';
import { Shirt, Camera, RotateCcw, Ruler } from 'lucide-react';

export const dynamic = 'force-dynamic';

export default async function HomePage() {
  const products = await prisma.product.findMany({
    where: { active: true },
    include: { colors: true, sizes: { orderBy: { sortOrder: 'asc' } } },
    orderBy: { createdAt: 'desc' },
  });

  return (
    <div className="min-h-screen">
      <Header />

      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary/10 via-background to-accent/20 py-16 md:py-24">
        <div className="mx-auto max-w-[1200px] px-4 text-center">
          <h1 className="font-display text-4xl font-bold tracking-tight md:text-5xl lg:text-6xl">
            Jouw <span className="text-primary">virtuele</span> paskamer
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-lg text-muted-foreground">
            Ontdek hoe kleding je staat — live met je camera of in 360° op een mannequin.
            Geen gedoe, geen pashokje.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-6 text-sm text-muted-foreground">
            <div className="flex items-center gap-2"><Camera className="h-5 w-5 text-primary" /> Live camera passen</div>
            <div className="flex items-center gap-2"><RotateCcw className="h-5 w-5 text-primary" /> 360° draaiweergave</div>
            <div className="flex items-center gap-2"><Ruler className="h-5 w-5 text-primary" /> Persoonlijk maatadvies</div>
          </div>
        </div>
      </section>

      {/* Products */}
      <section className="mx-auto max-w-[1200px] px-4 py-12">
        <h2 className="font-display text-2xl font-semibold tracking-tight mb-8">
          <Shirt className="inline mr-2 h-6 w-6 text-primary" />
          Onze collectie
        </h2>
        {(products ?? []).length === 0 ? (
          <p className="text-center text-muted-foreground py-12">Geen producten gevonden. Voeg producten toe via het beheerpaneel.</p>
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {(products ?? []).map((product: any, idx: number) => (
              <ProductCard
                key={product?.id ?? `p-${idx}`}
                id={product?.id ?? ''}
                name={product?.name ?? ''}
                price={product?.price ?? 0}
                imageUrl={product?.imageUrl ?? null}
                colors={(product?.colors ?? []).map((c: any) => ({ id: c?.id ?? '', name: c?.name ?? '', hexCode: c?.hexCode ?? '#ccc' }))}
              />
            ))}
          </div>
        )}
      </section>

      <PrivacyBanner />
    </div>
  );
}
