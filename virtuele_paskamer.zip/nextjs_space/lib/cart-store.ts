import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

export interface CartItem {
  productId: string;
  productName: string;
  colorId: string;
  colorName: string;
  colorHex: string;
  sizeId: string;
  sizeLabel: string;
  price: number;
  quantity: number;
  imageUrl: string | null;
}

interface CartStore {
  items: CartItem[];
  addItem: (item: Omit<CartItem, 'quantity'>) => void;
  removeItem: (productId: string, colorId: string, sizeId: string) => void;
  updateQuantity: (productId: string, colorId: string, sizeId: string, qty: number) => void;
  clearCart: () => void;
}

export const useCartStore = create<CartStore>()(
  persist(
    (set, get) => ({
      items: [],
      addItem: (item) => {
        set((state) => {
          const existing = (state?.items ?? []).find(
            (i: CartItem) => i?.productId === item?.productId && i?.colorId === item?.colorId && i?.sizeId === item?.sizeId
          );
          if (existing) {
            return {
              items: (state?.items ?? []).map((i: CartItem) =>
                i?.productId === item?.productId && i?.colorId === item?.colorId && i?.sizeId === item?.sizeId
                  ? { ...(i ?? {}), quantity: (i?.quantity ?? 0) + 1 }
                  : i
              ),
            };
          }
          return { items: [...(state?.items ?? []), { ...(item ?? {}), quantity: 1 }] };
        });
      },
      removeItem: (productId, colorId, sizeId) => {
        set((state) => ({
          items: (state?.items ?? []).filter(
            (i: CartItem) => !(i?.productId === productId && i?.colorId === colorId && i?.sizeId === sizeId)
          ),
        }));
      },
      updateQuantity: (productId, colorId, sizeId, qty) => {
        if (qty <= 0) {
          get()?.removeItem?.(productId, colorId, sizeId);
          return;
        }
        set((state) => ({
          items: (state?.items ?? []).map((i: CartItem) =>
            i?.productId === productId && i?.colorId === colorId && i?.sizeId === sizeId
              ? { ...(i ?? {}), quantity: qty }
              : i
          ),
        }));
      },
      clearCart: () => set({ items: [] }),
    }),
    {
      name: 'stijlvol-cart',
      storage: createJSONStorage(() => {
        if (typeof window !== 'undefined') return localStorage;
        return { getItem: () => null, setItem: () => {}, removeItem: () => {} };
      }),
    }
  )
);
