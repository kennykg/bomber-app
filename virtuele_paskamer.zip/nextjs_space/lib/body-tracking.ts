export interface Landmark { x: number; y: number; z?: number; visibility?: number }
export interface BodyPlacement {
  x: number; y: number; shoulder: number; torso: number;
  yaw: number; roll: number; estimated: boolean;
}
export type BodyStatus = 'searching' | 'partial' | 'tracked';

export function isVisible(point?: Landmark): point is Landmark {
  return !!point && Number.isFinite(point.x) && Number.isFinite(point.y)
    && (point.visibility ?? 0) >= 0.4 && point.x > -0.05 && point.x < 1.05
    && point.y > -0.05 && point.y < 1.02;
}

// One camera cannot measure physical clothing fit. These are screen-space anchors only.
export function getBodyPlacement(points: Landmark[] | null, width: number, height: number, world?: Landmark[] | null): BodyPlacement | null {
  if (!points) return null;
  const left = points[11], right = points[12];
  if (!isVisible(left) || !isVisible(right)) return null;
  const lx = (1 - left.x) * width, rx = (1 - right.x) * width;
  const ly = left.y * height, ry = right.y * height;
  const x = (lx + rx) / 2, y = (ly + ry) / 2;
  const projected = Math.hypot(rx - lx, ry - ly);
  const depth = ((right.z ?? 0) - (left.z ?? 0)) * width;
  // Preserve garment volume on a quarter turn rather than crushing it to shoulder pixels.
  const shoulder = Math.hypot(projected, depth);
  if (shoulder < width * 0.065 || shoulder > width * 1.3) return null;
  const lh = points[23], rh = points[24];
  const hipsVisible = isVisible(lh) && isVisible(rh);
  const torso = hipsVisible ? Math.hypot((1 - (lh.x + rh.x) / 2) * width - x, (lh.y + rh.y) / 2 * height - y) : shoulder * 1.3;
  const wl = world?.[11], wr = world?.[12];
  const yaw = wl && wr ? Math.atan2((wr.z ?? 0) - (wl.z ?? 0), wl.x - wr.x) : Math.atan2(depth, rx - lx);
  // Shoulder roll must not flip upside down when the user turns their back.
  const roll = -Math.atan2((ry - ly) * (rx >= lx ? 1 : -1), Math.max(Math.abs(rx - lx), shoulder * 0.25));
  return { x, y, shoulder, torso: Math.max(shoulder * 0.8, Math.min(torso, shoulder * 2.2)), yaw, roll, estimated: !hipsVisible };
}

export const BODY_GUIDANCE: Record<BodyStatus, string> = {
  searching: 'Geen betrouwbare schouders gevonden. Zet je telefoon rechtop, zorg voor licht van voren en breng beide schouders in beeld.',
  partial: 'Je schouders zijn in beeld. De jaslengte wordt geschat: stap achteruit tot je heupen zichtbaar zijn voor een betere plaatsing.',
  tracked: 'Bovenlichaam herkend. Beweeg rustig en houd je armen ontspannen langs je lichaam.',
};
