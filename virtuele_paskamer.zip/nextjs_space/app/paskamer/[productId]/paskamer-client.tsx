'use client';

import { useState, useCallback } from 'react';
import dynamic from 'next/dynamic';
import Image from 'next/image';
import { Camera, RotateCcw, ShoppingBag, Check, AlertCircle, Shirt } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { SizeAdvisor } from '@/components/size-advisor';
import { useCartStore } from '@/lib/cart-store';
import { getStockStatus } from '@/lib/garment-configs';
import { BOMBER_PRODUCT_ID } from '@/lib/bomber-config';
import { toast } from 'sonner';

const FittingRoom = dynamic(() => import('@/components/fitting-room').then((m) => m.FittingRoom), {
  ssr: false,
  loading: () => <div className="aspect-[4/3] w-full rounded-lg bg-muted animate-pulse" />,
});

const ThreeDViewer = dynamic(() => import('@/components/three-d-viewer').then((m) => m.ThreeDViewer), {
  ssr: false,
  loading: () => <div className="aspect-[4/3] w-full rounded-lg bg-muted animate-pulse" />,
});

const BomberViewer = dynamic(() => import('@/components/bomber-viewer').then(m => m.BomberViewer), {
  ssr: false,
  loading: () => <div className="aspect-[4/3] w-full rounded-lg bg-muted animate-pulse" />,
});

interface ProductData {
  id: string;
  name: string;
  description: string;
  price: number;
  imageUrl: string | null;
  garmentType: string;
  colors: { id: string; name: string; hexCode: string }[];
  sizes: { id: string; label: string }[];
  inventory: { colorVariantId: string; sizeVariantId: string; stock: number; colorName: string; sizeName: string }[];
}

export function PaskamerClient({ product }: { product: ProductData }) {
  const hasBomberModel = product.id === BOMBER_PRODUCT_ID;
  const colors = product?.colors ?? [];
  const sizes = product?.sizes ?? [];
  const [selectedColor, setSelectedColor] = useState(colors[0] ?? null);
  const [selectedSize, setSelectedSize] = useState(sizes[0] ?? null);
  const [shoulderWidth, setShoulderWidth] = useState<number | null>(null);
  const [torsoHeight, setTorsoHeight] = useState<number | null>(null);
  const addItem = useCartStore((s) => s?.addItem);

  const inv = (product?.inventory ?? []).find(
    (i: any) => i?.colorVariantId === selectedColor?.id && i?.sizeVariantId === selectedSize?.id
  );
  const stock = inv?.stock ?? 0;
  const stockStatus = getStockStatus(stock);

  const handleMeasurements = useCallback((sw: number, th: number) => {
    setShoulderWidth(sw);
    setTorsoHeight(th);
  }, []);

  const handleAddToCart = () => {
    if (!selectedColor || !selectedSize) { toast.error('Kies een kleur en maat'); return; }
    if (stock <= 0) { toast.error('Dit item is helaas uitverkocht'); return; }
    addItem?.({
      productId: product?.id ?? '',
      productName: product?.name ?? '',
      colorId: selectedColor?.id ?? '',
      colorName: selectedColor?.name ?? '',
      colorHex: selectedColor?.hexCode ?? '#ccc',
      sizeId: selectedSize?.id ?? '',
      sizeLabel: selectedSize?.label ?? '',
      price: product?.price ?? 0,
      imageUrl: product?.imageUrl ?? null,
    });
    toast.success('Toegevoegd aan winkelmandje!');
  };

  const handleSizeRecommend = useCallback((label: string) => {
    const found = sizes.find((s: any) => s?.label === label);
    if (found) setSelectedSize(found);
  }, [sizes]);

  return (
    <div className="mx-auto max-w-[1200px] px-4 py-6">
      {/* Product info header */}
      <div className="mb-6">
        <h1 className="font-display text-2xl font-bold tracking-tight md:text-3xl">{product?.name ?? 'Product'}</h1>
        <p className="text-lg font-semibold text-primary mt-1">€{(product?.price ?? 0)?.toFixed?.(2) ?? '0.00'}</p>
        <p className="text-muted-foreground mt-2">{product?.description ?? ''}</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
        {/* Main viewer */}
        <div>
          <Tabs defaultValue="camera">
            <TabsList className="mb-4">
              <TabsTrigger value="camera"><Camera className="mr-1 h-4 w-4" /> Live camera</TabsTrigger>
              <TabsTrigger value="3d"><RotateCcw className="mr-1 h-4 w-4" /> 360° weergave</TabsTrigger>
            </TabsList>
            <TabsContent value="camera">
              <FittingRoom
                garmentType={product?.garmentType ?? 'tshirt'}
                color={selectedColor?.hexCode ?? '#333333'}
                sizeLabel={selectedSize?.label ?? 'M'}
                onBodyMeasurements={handleMeasurements}
                hasBomberModel={hasBomberModel}
              />
            </TabsContent>
            <TabsContent value="3d">
              {hasBomberModel ? (
                <BomberViewer color={selectedColor?.hexCode ?? '#111111'} sizeLabel={selectedSize?.label ?? 'M'} />
              ) : (
                <ThreeDViewer
                  garmentType={product?.garmentType ?? 'tshirt'}
                  color={selectedColor?.hexCode ?? '#333333'}
                  sizeLabel={selectedSize?.label ?? 'M'}
                />
              )}
            </TabsContent>
          </Tabs>
        </div>

        {/* Controls sidebar */}
        <div className="space-y-5">
          {/* Product image */}
          {product?.imageUrl && (
            <div className="relative aspect-square w-full max-w-[200px] overflow-hidden rounded-lg bg-muted mx-auto lg:mx-0">
              <Image src={product.imageUrl} alt={product?.name ?? ''} fill className="object-cover" sizes="200px" />
            </div>
          )}

          {/* Color picker */}
          <div>
            <h3 className="text-sm font-medium mb-2">Kleur: <span className="text-muted-foreground">{selectedColor?.name ?? ''}</span></h3>
            <div className="flex flex-wrap gap-2">
              {colors.map((c: any, ci: number) => (
                <button
                  key={c?.id ?? `clr-${ci}`}
                  onClick={() => setSelectedColor(c)}
                  className={`h-9 w-9 rounded-full border-2 transition-all ${selectedColor?.id === c?.id ? 'border-primary scale-110 ring-2 ring-primary/30' : 'border-border hover:border-primary/50'}`}
                  style={{ backgroundColor: c?.hexCode ?? '#ccc' }}
                  title={c?.name ?? ''}
                />
              ))}
            </div>
          </div>

          {/* Size picker */}
          <div>
            <h3 className="text-sm font-medium mb-2">Maat</h3>
            <div className="flex flex-wrap gap-2">
              {sizes.map((s: any, si: number) => {
                const sInv = (product?.inventory ?? []).find(
                  (i: any) => i?.colorVariantId === selectedColor?.id && i?.sizeVariantId === s?.id
                );
                const sStock = sInv?.stock ?? 0;
                return (
                  <button
                    key={s?.id ?? `sz-${si}`}
                    onClick={() => setSelectedSize(s)}
                    disabled={sStock <= 0}
                    className={`h-10 min-w-[44px] rounded-md border px-3 text-sm font-medium transition-all
                      ${selectedSize?.id === s?.id ? 'border-primary bg-primary text-primary-foreground' : 'border-border bg-card hover:border-primary/50'}
                      ${sStock <= 0 ? 'opacity-40 cursor-not-allowed line-through' : ''}`}
                  >
                    {s?.label ?? ''}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Stock status */}
          <div className="flex items-center gap-2">
            {stock > 0 ? <Check className="h-4 w-4 text-green-600" /> : <AlertCircle className="h-4 w-4 text-destructive" />}
            <span className={`text-sm font-medium ${stockStatus?.color ?? ''}`}>{stockStatus?.label ?? ''}</span>
            {stock > 0 && stock <= 10 && <span className="text-xs text-muted-foreground">({stock} stuks)</span>}
          </div>

          {/* Add to cart */}
          <Button className="w-full" size="lg" onClick={handleAddToCart} disabled={stock <= 0}>
            <ShoppingBag className="mr-2 h-5 w-5" />
            {stock > 0 ? 'In winkelmandje' : 'Uitverkocht'}
          </Button>

          {/* Size advisor */}
          <SizeAdvisor
            shoulderWidth={shoulderWidth}
            torsoHeight={torsoHeight}
            sizes={sizes}
            onRecommend={handleSizeRecommend}
          />
        </div>
      </div>
    </div>
  );
}
