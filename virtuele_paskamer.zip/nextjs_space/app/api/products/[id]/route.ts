export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const product = await prisma.product.findUnique({
      where: { id },
      include: {
        colors: true,
        sizes: { orderBy: { sortOrder: 'asc' } },
        inventory: {
          include: { colorVariant: true, sizeVariant: true },
        },
      },
    });
    if (!product) {
      return NextResponse.json({ error: 'Product niet gevonden' }, { status: 404 });
    }
    return NextResponse.json(product);
  } catch (err: any) {
    console.error('Product fetch error:', err);
    return NextResponse.json({ error: 'Kon product niet ophalen' }, { status: 500 });
  }
}
