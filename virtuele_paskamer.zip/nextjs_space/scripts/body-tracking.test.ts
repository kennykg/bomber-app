import assert from 'node:assert/strict';
import { test } from 'node:test';
import { getBodyPlacement, type Landmark } from '../lib/body-tracking';

function body(): Landmark[] {
  const p = Array.from({ length: 33 }, () => ({ x: 0.5, y: 0.5, z: 0, visibility: 1 }));
  p[11] = { x: 0.7, y: 0.3, z: 0, visibility: 1 };
  p[12] = { x: 0.3, y: 0.3, z: 0, visibility: 1 };
  p[23] = { x: 0.6, y: 0.85, z: 0, visibility: 1 };
  p[24] = { x: 0.4, y: 0.85, z: 0, visibility: 1 };
  return p;
}

test('volledig bovenlichaam geeft stabiele plaatsing', () => {
  const result = getBodyPlacement(body(), 640, 480)!;
  assert.equal(result.estimated, false);
  assert.equal(result.x, 320);
  assert.equal(result.y, 144);
  assert.equal(result.yaw, 0);
  assert.ok(result.shoulder > 0 && result.torso > 0);
});
test('heupen buiten beeld verbergen de 3D-jas niet', () => {
  const p = body(); p[23].y = 1.3; p[24].visibility = 0.05;
  assert.equal(getBodyPlacement(p, 640, 852)?.estimated, true);
});
test('ontbrekende of onbetrouwbare schouders verbergen de jas', () => {
  assert.equal(getBodyPlacement(null, 640, 480), null);
  const p = body(); p[11].visibility = 0.1;
  assert.equal(getBodyPlacement(p, 640, 480), null);
  p[11].visibility = 1; p[11].x = Number.NaN;
  assert.equal(getBodyPlacement(p, 640, 480), null);
});
test('draaien behoudt volume en keert de jas niet ondersteboven', () => {
  const p = body(); p[11].x = 0.53; p[12].x = 0.47; p[11].z = -0.2; p[12].z = 0.2;
  const side = getBodyPlacement(p, 640, 480)!;
  assert.ok(side.shoulder > 200); assert.ok(side.yaw > 1);
  p[11].x = 0.3; p[12].x = 0.7; p[11].z = 0; p[12].z = 0;
  const back = getBodyPlacement(p, 640, 480)!;
  assert.equal(Math.abs(back.yaw), Math.PI); assert.equal(Math.abs(back.roll), 0);
});
